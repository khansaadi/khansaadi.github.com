vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|26 Oct 2021 07:24:32 -0000
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|
vti_author:SR|DESKTOP-5FRR1NR\\Doug
vti_modifiedby:SR|DESKTOP-5FRR1NR\\Doug
vti_timecreated:TR|02 Aug 2021 08:40:58 -0000
vti_nexttolasttimemodified:TW|26 Oct 2021 06:52:31 -0000
vti_cacheddtm:TX|26 Oct 2021 07:24:32 -0000
vti_filesize:IR|2458
