(function($) {
	"use strict";
	$(function() {
		var header = $(".start-style");
		$(window).scroll(function() {
			var scroll = $(window).scrollTop();
			if (scroll >= 10) {
				header.removeClass('start-style').addClass("scroll-on");
			} else {
				header.removeClass("scroll-on").addClass('start-style');
			}
		});
	});

	//Animation
	$(document).ready(function() {
		$('.hero-banner-animated').removeClass('hero-banner-animated');
	});

	//Menu On Hover
	$('body').on('mouseenter mouseleave', '.nav-item', function(e) {
		if ($(window).width() > 768) {
			var _d = $(e.target).closest('.nav-item');
			_d.addClass('show');
			setTimeout(function() {
				_d[_d.is(':hover') ? 'addClass' : 'removeClass']('show');
			}, 1);
		}
	});
})(jQuery);

// Contact Form Submission 
function sendEmail() {

	var name = $("#name");
	var email = $("#email");
	var body = $("#body");

	if (isNotEmpty(name) && isNotEmpty(email) && isNotEmpty(body)) {
		
		$.ajax({
			url: 'sendEmail.php',
			method: 'POST',
			dataType: 'json',
			data: {
				name: name.val(),
				email: email.val(),
				body: body.val()
			},
			success: function(send) {

				// Receiving the response message from php in json code fromat done at php side in array
				// and caling the object in the array using send.response, also for status send.status  
				if(send.response === "Thanks, We will be in touch soon."){
					$('#myForm')[0].reset();
						document.getElementById("formSubmitted").style.display = "none";
						document.getElementById("contactNotify").style.display = "block";
						document.getElementById("emailNotify").style.display = "none";
						$('.sent-notification').text(send.response);
					}
					else if(send.response === "Invalid email format"){
						document.getElementById("emailNotify").style.display = "block";
						$('#emailNotify').text(send.response);
					}
					else{
						$('#myForm')[0].reset();
						document.getElementById("formSubmitted").style.display = "none";
						document.getElementById("contactNotify").style.display = "block";
						document.getElementById("emailNotify").style.display = "none";
						$('.sent-notification').text(send.response);
					}
				},
			});
	}
}

function isNotEmpty(caller) {
	if (caller.val() == "") {
		caller.css('border', '2px solid red');
		return false;
	} else caller.css('border', '2px solid #FEA855');
	return true;
}
