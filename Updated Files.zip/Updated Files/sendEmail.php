<?php
    use PHPMailer\PHPMailer\PHPMailer;

    if (isset($_POST['name']) && isset($_POST['email'])) {

        $name = $_POST['name'];
        $email = $_POST['email'];
        $theMessage = $_POST['body'];
        $subject = "New Form Submission on Expat Mentors";
     
        // Adding email template
        ob_start();
        include 'emailTemplate.php';
        $body = ob_get_clean();

        // replacing the %username% with the actual values
        $body = str_replace('%username%', $name, $body);
        $body = str_replace('%useremail%', $email, $body);
        $body = str_replace('%usermessage%', $theMessage, $body);

        require_once "PHPMailer/PHPMailer.php";
        require_once "PHPMailer/SMTP.php";
        require_once "PHPMailer/Exception.php";

        $mail = new PHPMailer();

        //SMTP Settings
        $mail->isSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = true;
        $mail->Username = "azazmuzaffar@gmail.com"; 
        $mail->Password = 'azazmoon0350'; 
        $mail->Port = 465;
        $mail->SMTPSecure = "ssl";

        //Email Settings
        $mail->isHTML(true);
        $mail->From = $email;
        $mail->FromName = $name;
        $mail->addAddress("azazmuzaffar.work@gmail.com"); 
        $mail->setFrom($email, $name);
        $mail->Subject = $subject;
        $mail->MsgHTML($body);

        //Checking if the email is valid
        $user_email = $_POST["email"];
        if (!filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
            $status = "failed";
            $response= "Invalid email format";
            exit(json_encode(array("status" => $status, "response" => $response)));
        }
        else{
            //If valid email then checking the email is sent or not
            if ($mail->send()) {
                $status = "success";
                $response = "Thanks, We will be in touch soon.";
                $s = true;
            } else {
                $status = "failed";
                $response = "Something went wrong!";
                $s = false;
            }
            exit(json_encode(array("status" => $status, "response" => $response)));
        }
    }
?>
