vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|17 Oct 2022 10:24:18 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|DESKTOP-5FRR1NR\\Doug
vti_modifiedby:SR|DESKTOP-5FRR1NR\\Doug
vti_timecreated:TR|01 Aug 2021 15:57:40 -0000
vti_title:SR|Book by Lynda Brettle | Expat Mentors
vti_nexttolasttimemodified:TR|23 Sep 2022 11:16:38 -0000
vti_cacheddtm:TX|17 Oct 2022 10:24:18 -0000
vti_filesize:IR|6129
vti_cachedtitle:SR|Book by Lynda Brettle | Expat Mentors
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|/font-awesome/css/all.css Q|/bootstrap/css/bootstrap.min.css Q|/cookienoticepro/style/cookienoticepro.style.css Q|/style.css H|https://www.expatmentors.com/ H|https://www.amazon.co.uk/dp/B08BRHDMNM S|/_a_images/book.jpg S|/book-i/lynda-brettle-book.jpg H|https://www.expatmentors.com/book/ H|https://www.expatmentors.com/book/ H|https://www.expatmentors.com/book/ S|/jquery/jquery.min.js S|/cookienoticepro/cookienoticepro.script.js S|/bootstrap/js/bootstrap.min.js S|/js/script.js
vti_cachedsvcrellinks:VX|NQUS|file:///font-awesome/css/all.css NQUS|file:///bootstrap/css/bootstrap.min.css NQUS|file:///cookienoticepro/style/cookienoticepro.style.css NQUS|file:///style.css NHSS|https://www.expatmentors.com/ NHSS|https://www.amazon.co.uk/dp/B08BRHDMNM NSUS|file:///_a_images/book.jpg NSUS|file:///book-i/lynda-brettle-book.jpg NHSS|https://www.expatmentors.com/book/ NHSS|https://www.expatmentors.com/book/ NHSS|https://www.expatmentors.com/book/ NSUS|file:///jquery/jquery.min.js NSUS|file:///cookienoticepro/cookienoticepro.script.js NSUS|file:///bootstrap/js/bootstrap.min.js NSUS|file:///js/script.js
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|viewport \\ width=device-width,\\ initial-scale=1 HTTP-EQUIV=Content-Type text/html;\\ charset=utf-8 description Offering\\ life\\ coaching,\\ personal\\ counselling\\ and\\ emotional\\ healing\\ at\\ home\\ or\\ away.\\ Helping\\ expatriates\\ handle\\ the\\ psychological\\ and\\ stressful\\ aspects\\ of\\ life\\ abroad. keywords Expat\\ living,\\ life\\ coaching,\\ counselling\\ and\\ healing,\\ Spain,\\ Costa\\ Blanca,\\ Wellness,\\ mentoring,\\ Brains\\ at\\ the\\ Border,\\ Lynda\\ Brettle
vti_charset:SR|utf-8
vti_backlinkinfo:VX|
