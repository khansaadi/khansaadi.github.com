<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<meta content=" width=device-width, initial-scale=1" name="viewport" />
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	<title>Book by Lynda Brettle | Expat Mentors</title>
	<meta name="description" content="Offering life coaching, personal counselling and emotional healing at home or away. Helping expatriates handle the psychological and stressful aspects of life abroad." />
	<meta name="keywords" content="Expat living, life coaching, counselling and healing, Spain, Costa Blanca, Wellness, mentoring, Brains at the Border, Lynda Brettle" />
	<link rel="stylesheet" href="/style.css" />
</head>

<body>
	<div class="overlay">
		<!-- >>>>>>>>>>>>>>> NAVBAR <<<<<<<<<<<<<<<<< -->
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/header.php'); ?>

		<!-- >>>>>>>>>>>>>>>>> HERO BANNER <<<<<<<<<<<<<<<<<<< -->

		<div class="hero-banner-animated">
			<div class="section full-height">
				<div class="absolute-center book-page">
					<div class="section">
						<div class="container">
							<div class="row">
								<div class="col-12">
									<h1 class="text-white">
										<span class="para-before">Checkout</span>
										<br />
										<div class="heading-word-wrap">
											<span>B</span> 
											<span>r</span> 
											<span>a</span> 
											<span>i</span> 
											<span>n</span>
											<span>s</span>
										</div>
										&nbsp;
										<div class="heading-word-wrap">
											<span>A</span> 
											<span>t</span>
										</div>
										<br />
										<div class="heading-word-wrap">
										<span>T</span>
										<span>h</span> 
										<span>e</span>
										</div>
										&nbsp;
										<div class="heading-word-wrap">
										<span>B</span> 
										<span>o</span>
										<span>r</span> 
										<span>d</span> 
										<span>e</span>
										<span>r</span>
										</div>
									</h1>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="social-icons">
					<ul>
						<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/contact-details-top.php'); ?>
					</ul>
				</div>
			</div>
		</div>

		<div class="my-5 py-5"></div>

		<!-- >>>>>>>>>>>>>>>>> MAIN CONTENT <<<<<<<<<<<<<<<<<<< -->

		<div class="body-content">
			<div class="container-fluid">
				<div class="content-area">
					<div class="direction">
						<p><a title="Counselling and coaching on the Costa Blanca in Spain" href="https://www.expatmentors.com/">Home</a> / Book</p>
					</div>
					<div class="book-info py-4">
						<h1 class="text-center pb-3">"Brains at the Border" by Lynda Brettle (Expat Mentors)</h1>
						<p class="text-center pb-4">
							from
							<a title="Brains At The Border by Lynda Brettle" target="_blank" href="https://www.amazon.co.uk/dp/B08BRHDMNM">Amazon</a> and all other
							regional Amazon sites.
						</p>
						<img class="w-xs-100" alt="Counselling and coaching on the Costa Blanca in Spain" src="/_a_images/book.jpg" />
					</div>
					<div class="pb-4">
						<p class="text-center">
							<span>Order your copy now!</span> Available in paperback and kindle editions in English
						</p>
						<img class="w-xs-100" alt="Counselling and coaching on the Costa Blanca in Spain" src="/_a_images/lynda-brettle-book.jpg" />
					</div>
					<div class="book-discrip">
						<h3>Having reached Number One in Amazon's Travel Writing Chart in 2020, the book has attracted a string of five-star reviews!</h3>
						<p>&quot;Living abroad is not the same as a holiday. Moving overseas for the first time,
							especially under your own steam, can be like getting behind the wheel of a car
							without any driving lessons and heading straight into the M4 traffic. <a title="Brains At The Border by Lynda Brettle" target="_self" href="https://www.expatmentors.com/book/">Brains at the Border</a> provides the guidance and support needed to avoid disaster. This new guide
							has been described as a "life lesson" "helpful" and a "great insight into relationship survival".</p>
						<p>&quot;In <a title="Brains At The Border by Lynda Brettle" target="_self" href="https://www.expatmentors.com/book/">Brains at the Border</a>, Lynda offers us a humorous insight into her own overseas
							experiences during postings with the Foreign Office over two decades in locations as
							diverse as paradise islands and war torn conflict zones. With each new adventure we
							experience with her, and her eclectic bunch of fellow globe trotters, how it really
							feels to live and work as an expatriate and how they deal with both the rewards and
							frustrations of basic everyday issues".</p>
						<p>&quot;Lynda’s world gets increasing complex as she travels from being a single girl to a
							married woman and a mother. In an attempt to regain some work – life balance, she
							leaves the Diplomatic Service and settles with her family on Spain’s Costa Blanca.
							This is where the jaw-dropping fun really begins with the arrival of hordes of
							ill-prepared Brits expecting to “live the dream” – having left their <a title="Brains At The Border by Lynda Brettle" target="_self" href="https://www.expatmentors.com/book/">Brains at the Border</a>"</p>
					</div>
				</div>
			</div>
		</div>

		<!-- >>>>>>>>>>>>>>> FOOTER <<<<<<<<<<<<<<<<< -->
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/footer.php'); ?>
	</div>

	<!-- >>> JQUERY <<< -->
	<script src="/jquery/jquery.min.js"></script>
	<script src="/cookienoticepro/cookienoticepro.script.js"></script>

	<script>
		$(document).ready(function() {
			// Initialize cookie consent banner
			cookieNoticePro.init();
		});

		// IMPORTANT: If you are not showing cookie preferences selection menu,
		// then you can remove the below function
		const injectScripts = () => {
			// Example: Google Analytics
			if (cookieNoticePro.isPreferenceAccepted("analytics") === true) {
				console.log("Analytics Scripts Running....");
			}

			// Example: Google Adwords cookie, DoubleClick, Remarketing pixels, Social Media cookies
			if (cookieNoticePro.isPreferenceAccepted("marketing") === true) {
				console.log("Marketing Scripts Running....");
			}

			// Example: Remember password, language, etc
			if (cookieNoticePro.isPreferenceAccepted("preferences") === true) {
				console.log("Preferences Scripts Running....");
			}
		}
	</script>
	<!-- >>> Bootstrap | Front End Framework <<< -->
	<script src="/bootstrap/js/bootstrap.min.js"></script>

	<!-- >>> CUSTOM JS <<< -->
	<script src="/js/script.js"></script>
</body>

</html>