<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta content=" width=device-width, initial-scale=1" name="viewport">
	<meta content='text/html; charset=utf-8' http-equiv='Content-Type'>
	<title>Contact | Lynda Brettle</title>
	<meta name="description" content="Offering life coaching, personal counselling and emotional healing at home or away. Helping expatriates handle the psychological and stressful aspects of life abroad.">
	<meta name="keywords" content="Expat living, life coaching, counselling and healing, Spain, Costa Blanca, Wellness, mentoring, Brains at the Border, Lynda Brettle" />

	<!-- >>> Bootstrap 4 | Front End Framework <<< -->
	<!-- <link rel="stylesheet" href="/font-awesome/css/all.css"> -->

	<!-- >>> Fontawesome 5 | Used for icons <<< -->
	<!-- <link rel='stylesheet' href='/bootstrap/css/bootstrap.min.css'>
	<link rel="stylesheet" href="/cookienoticepro/style/cookienoticepro.style.css"> -->
	<link rel='stylesheet' href='/style.css'>
	<!-- >>> jQuery Validate <<< -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
	<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

	<script>
		$(document).ready(function() {
			$("#cform").validate({
				rules: {
					firstname: {
						required: true,
						minlength: 3,
						pattern: "^[a-zA-Z ]+"
					},
					surname: {
						required: true,
						minlength: 3,
						pattern: "^[a-zA-Z ]+"
					},
					email: {
						required: true,
						email: true,
						minlength: 10
					},
					phone: {
						required: false,
						phoneUS: true
					},
					message: {
						required: true,
						minlength: 4
					}
				},
				messages: {
					firstname: {
						minlength: "Name should be at least 4 characters.",
						regex: "Please provide Letters only.",
						pattern: "Please provide Letters only."
					},
					surname: {
						minlength: "Name should be at least 4 characters.",
						pattern: "Please provide Letters only."
					},
					email: {
						email: "Please Type a valid email address."
					},
					phone: {
						matches: "Please Type a valid Phone Number."
					},
					message: {
						minlength: "Description should be more than 4 words",
						required: "Please provide description"
					}
				}
			});
		});
	</script>
	<script src='https://www.google.com/recaptcha/api.js' async defer></script>
	<script>
		function checkRecaptcha() {
			if ($("#cform").valid()) {
				var response = grecaptcha.getResponse();
				if (response.length == 0) {
					//reCaptcha not verified
					$('#errorCaptureMesg').html('Unable to verify Captcha');
				} else {
					//reCaptch verified 
					var Data = {
						"sendMailer": true,
						"name": $('input#firstname').val(),
						"surname": $('input#surname').val(),
						"email": $('input#email').val(),
						"phone": $('input#phone').val(),
						"message": $('textarea#message').val()
					}
					$.ajax({
						type: "POST",
						url: 'sendMailer.php',
						data: Data,
						success: function(data) {
							if (data == "Success") {
								alert("Your Message was sent.");
							} else {
								alert("An error occured sending message, Please double check your email.");
							}
						}
					});
					document.querySelector("form#cform").reset();
				}
			} else {
				var validator = $("#cform").validate();
				validator.form();
			}
		}
		// implement on the backend
		function backend_API_challenge() {
			var response = grecaptcha.getResponse();
			$.ajax({
				type: "POST",
				url: 'https://www.google.com/recaptcha/api/siteverify',
				data: {
					"secret": "6LfHAeEcAAAAACSeNq6wJ9dOpW4vSzN0WdQ4euhc",
					"response": response,
					"remoteip": "localhost"
				},
				contentType: 'application/x-www-form-urlencoded',
				success: function(data) {
					console.log(data);
				}
			});
		}
	</script>
</head>

<body>
	<div class="overlay">

		<!-- >>>>>>>>>>>>>>> NAVBAR <<<<<<<<<<<<<<<<< -->
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/header.php'); ?>

		<!-- >>>>>>>>>>>>>>>>> HERO BANNER <<<<<<<<<<<<<<<<<<< -->

		<div class="hero-banner-animated">
			<div class="section full-height">
				<div class="absolute-center the-contact">
					<div class="section">
						<div class="container">
							<div class="row">
								<div class="col-12">
									<h1 class="text-white">
										<span class="para-before">Book a session now!</span>
										<div class="heading-word-wrap">
											<span>C</span> 
											<span>o</span> 
											<span>n</span> 
											<span>t</span> 
											<span>a</span> 
											<span>c</span> 
											<span>t</span>
										</div>
										&nbsp;
										<div class="heading-word-wrap">
											<span>L</span> 
											<span>y</span> 
											<span>n</span> 
											<span>d</span> 
											<span>a</span> 
											<span>!</span>
										</div>
									</h1>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="social-icons">
					<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/contact-details-top.php'); ?>
				</div>
			</div>
		</div>

		<div class="my-5 py-5"></div>


		<div class="body-content contact-page">
			<div class="container-fluid">
				<div class="content-area bg-light">
					<div class="direction">
						<p>
							<a title="Counselling and coaching on the Costa Blanca in Spain" href="https://www.expatmentors.com/">Home</a> / Contact Lynda!
						</p>
					</div>
					<div class="form-area">
						<h3 class="text-center pt-4">We'd love to hear from you! Just choose any of the ways below:</h3>
						<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/contact-details-bottom.php'); ?>
						<div class="d-flex justify-content-center py-5">
							<form id="cform" class="w-100" method="post">
								<div class="form-group">
									<label for="firstname">First Name <label for="firstname" generated="true" class="error"></label> </label>
									<input type="text" name="firstname" class="form-control" id="firstname" required>
								</div>
								<div class="form-group">
									<label for="surname">Last Name <label for="surname-error" generated="true" class="error"></label></label>
									<input type="text" name="surname" class="form-control" id="surname" required>
								</div>
								<div class="form-group">
									<label for="email">Email Address <label for="email-error" generated="true" class="error"></label></label>
									<input type="email" name="email" class="form-control" id="email" required>
								</div>
								<div class="form-group">
									<label for="phone">Phone Number <small>(Optional) </small> <label for="phone-error" generated="true" class="error"></label></label>
									<input type="tel" name="phone" class="form-control" id="phone" required>
								</div>
								<div class="form-group">
									<label for="message">Please mention what help you are looking for and whether
										you would prefer in person or remote.</small> <label for="phone-error" generated="true" class="error"></label></label>
									<textarea name="message" class="form-control" id="message" rows="8" required></textarea>
								</div>

								<!-- <div class="row"> -->
								<div class="row recapthca">
									<div class="col-md-4">
										<div class="g-recaptcha" data-sitekey="6LfHAeEcAAAAAA0ULtO4JhvxeVvS83VSlrfHHTlX"></div>
									</div>
									<div class="col-md-4">
										<span id="errorCaptureMesg"></span>
									</div>
								</div>
								<input value="Send enquiry" type="button" onclick="checkRecaptcha();" class="btn btn-primary">
							</form>
						</div>
					</div>
					<p>Expat Mentors Ltd
						<br>
						2nd Floor
						<br>
						College House
						<br>
						17 King Edwards Road
						<br>
						Ruislip
						<br>
						London
						<br>
						HA4 7AE
					</p>
					<br>
					<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/contact-details-bottom.php'); ?>
				</div>
			</div>
		</div>
		<!-- >>>>>>>>>>>>>>> FOOTER <<<<<<<<<<<<<<<<< -->
		<div class="contact--footer">
			<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/footer.php'); ?>
		</div>

	</div>

	<!-- >>> JQUERY <<< -->
	<!-- Jquery is added above using CDN for the Access of the Validate method, So disabled here -->
	<!-- <script src='/jquery/jquery.min.js'></script> -->

	<!-- >>> Bootstrap | Front End Framework <<< -->
	<script src='/bootstrap/js/bootstrap.min.js'></script>

	<!-- >>> CUSTOM JS <<< -->
	<script src="/js/script.js"></script>
</body>

</html>