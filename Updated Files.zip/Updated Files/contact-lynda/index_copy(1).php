<!DOCTYPE html>
<html lang="en" >
<head>
	<meta charset="utf-8">
  	<meta content=" width=device-width, initial-scale=1" name="viewport">
  	<meta content='text/html; charset=utf-8' http-equiv='Content-Type'>
  	<title>Contact | Lynda Brettle</title>
	<meta name="description" content="Offering life coaching, personal counselling and emotional healing at home or away. Helping expatriates handle the psychological and stressful aspects of life abroad.">
	<meta name="keywords" content="Expat living, life coaching, counselling and healing, Spain, Costa Blanca, Wellness, mentoring, Brains at the Border, Lynda Brettle"/> 

	<!-- >>> Bootstrap 4 | Front End Framework <<< -->
	<link rel="stylesheet" href="/font-awesome/css/all.css">

	<!-- >>> Fontawesome 5 | Used for icons <<< -->
	<link rel='stylesheet' href='/bootstrap/css/bootstrap.min.css'>

	<!-- >>> Custom CSS <<< -->
	<link rel='stylesheet' href='/style.css'>
</head>
<body>	

<div class="overlay">
	
	<!-- >>>>>>>>>>>>>>> NAVBAR <<<<<<<<<<<<<<<<< -->
	<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/header.php'); ?>

	<!-- >>>>>>>>>>>>>>>>> HERO BANNER <<<<<<<<<<<<<<<<<<< -->

	<div class="hero-banner-animated">
		<div class="section full-height">
			<div class="absolute-center the-contact">
				<div class="section">
					<div class="container">
						<div class="row">
							<div class="col-12">
								<h1><span class="para-before">Book a session now!</span><br>
								<span>C</span> <span>o</span> <span>n</span> <span>t</span> <span>a</span> <span>c</span> <span>t</span> &nbsp; <span>L</span> <span>y</span> <span>n</span> <span>d</span> <span>a</span> <span>!</span></h1>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="social-icons">
				<ul>
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/contact-details.php'); ?>
				</ul>
			</div>
		</div>
	</div>

	<div class="my-5 py-5"></div>

	<!-- >>>>>>>>>>>>>>>>> MAIN CONTENT <<<<<<<<<<<<<<<<<<< -->

	<div class="body-content contact-page">
		<div class="container-fluid">
			<div class="content-area">
				<div class="direction">
					<p><a href="https://www.expatmentors.com/">Home</a> / Contact Lynda!</p>
				</div>
				<div class="form-area">
					<p>We'd love to hear from you!</p>
					<div class="container">
						<div class="row input-container">
							<form id="myForm" name="myForm" onclick="sendEmail(); return false" >
								<div class="col-lg-12">
									<div class="styled-input wide">
										<input id="name" name="name" placeholder="Name" required="" type="text" required>
									</div>
								</div>
								<div class="col-lg-12">
									<div class="styled-input">
										<input id="email" name="email" placeholder="Email" required="" type="email" required>
									</div>
								</div>
								<p id="emailNotify">Invalid email format</p>
								<div class="col-lg-12">
									<div class="styled-input wide">
										<textarea id="body" name="body" placeholder="Message" required="" required></textarea>
									</div>
								</div><br>
								<div class="col-lg-12" id="formSubmitted">
									<button type="button">Send Message &nbsp; <i class="fas fa-paper-plane" style="font-size: 18px;"></i></button>
								</div>
								<p id="contactNotify" class="sent-notification"></p>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- >>>>>>>>>>>>>>> FOOTER <<<<<<<<<<<<<<<<< -->
	<div class="contact--footer">
		<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/footer.php'); ?>
	</div>

</div>

	<!-- >>> JQUERY <<< -->
  	<script src='/jquery/jquery.min.js'></script>

	<!-- >>> Bootstrap | Front End Framework <<< -->
	<script src='/bootstrap/js/bootstrap.min.js'></script>

	<!-- >>> CUSTOM JS <<< -->
  	<script src="/js/script.js"></script>
</body>
</html>