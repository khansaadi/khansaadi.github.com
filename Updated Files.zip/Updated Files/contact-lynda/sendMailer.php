<?php
    if(isset($_POST['sendMailer'])){
				$name = $_POST['name'];
				$lastName = $_POST['surname'];
				$emailAddress = $_POST['email'];
				$mobile = $_POST['phone'];
				$message = $_POST['message'];

				$to = "lynda@expatmentors.com  \r\n";
				$subject = "New message received - Contact us form";
				$header  = "MIME-Version: 1.0" . "\r\n";
				$header .= "Content-type:text/html;charset=utf-8" . "\r\n";
				$header .= "X-Mailer: PHP/" . phpversion() . "\r\n";
				$header .= "From: no-reply@expatmentors.com Expatmentors Contact Lynda \r\n";
				$body = "
                        <div style='margin:0px auto !important;width:50%;background:#f9f9f9;padding:50px;'>
                            <table style='width:100%;margin:0px auto'>
                                <tr style='background:#fff;padding:15px;margin:0px auto;border-radius:15px;'>
                                    <td style='padding:20px;width:50% !important;word-wrap:break-word;'>
                                        <h2 style=';font-weight:600'>New message received:</h2> 
                                    
                                        <p><b>First Name:</b> $name</p>
                                        <p><b>Last Surname:</b> $lastName</p>
                                        <p><b>Email Address:</b> $emailAddress</p>
                                        <p><b>Phone Number:</b> $mobile</p>
                                        <p><b>Message:</b> <br>
                                        $message
                                    </p>
                                    <br>    
                                    Thank you!.
                                    </td>
                                </tr>
                            </table>  
                            </div>
                        ";
				if(@mail($to,$subject,$body,$header)){
                    echo "Success";
                }	
	}
	 ?>