vti_encoding:SR|utf8-nl
vti_author:SR|DESKTOP-5FRR1NR\\Doug
vti_modifiedby:SR|DESKTOP-5FRR1NR\\Doug
vti_timelastmodified:TR|26 Oct 2021 15:07:42 -0000
vti_timecreated:TR|26 Oct 2021 14:36:46 -0000
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|26 Oct 2021 16:18:18 -0000
vti_cacheddtm:TX|26 Oct 2021 15:07:42 -0000
vti_filesize:IR|1979
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
