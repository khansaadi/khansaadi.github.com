vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|17 Oct 2022 10:36:21 -0000
vti_extenderversion:SR|6.0.2.5516
vti_title:SR|Contact | Lynda Brettle
vti_modifiedby:SR|DESKTOP-5FRR1NR\\Doug
vti_nexttolasttimemodified:TW|13 Oct 2022 13:03:38 -0000
vti_backlinkinfo:VX|
vti_author:SR|DESKTOP-5FRR1NR\\Doug
vti_timecreated:TR|02 Aug 2021 09:42:05 -0000
vti_cacheddtm:TX|17 Oct 2022 10:36:21 -0000
vti_filesize:IR|8790
vti_cachedtitle:SR|Contact | Lynda Brettle
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|/font-awesome/css/all.css Q|/bootstrap/css/bootstrap.min.css Q|/cookienoticepro/style/cookienoticepro.style.css Q|/style.css S|https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js S|https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js S|https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js S|https://www.google.com/recaptcha/api.js H|https://www.expatmentors.com/ S|/bootstrap/js/bootstrap.min.js S|/js/script.js
vti_cachedsvcrellinks:VX|NQUS|file:///font-awesome/css/all.css NQUS|file:///bootstrap/css/bootstrap.min.css NQUS|file:///cookienoticepro/style/cookienoticepro.style.css NQUS|file:///style.css NSSS|https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js NSSS|https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js NSSS|https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js NSSS|https://www.google.com/recaptcha/api.js NHSS|https://www.expatmentors.com/ NSUS|file:///bootstrap/js/bootstrap.min.js NSUS|file:///js/script.js
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|viewport \\ width=device-width,\\ initial-scale=1 HTTP-EQUIV=Content-Type text/html;\\ charset=utf-8 description Offering\\ life\\ coaching,\\ personal\\ counselling\\ and\\ emotional\\ healing\\ at\\ home\\ or\\ away.\\ Helping\\ expatriates\\ handle\\ the\\ psychological\\ and\\ stressful\\ aspects\\ of\\ life\\ abroad. keywords Expat\\ living,\\ life\\ coaching,\\ counselling\\ and\\ healing,\\ Spain,\\ Costa\\ Blanca,\\ Wellness,\\ mentoring,\\ Brains\\ at\\ the\\ Border,\\ Lynda\\ Brettle
vti_charset:SR|utf-8
