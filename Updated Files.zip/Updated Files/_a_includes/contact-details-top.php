<div class="contacts-header">
    <ul class="contact-icons">
        <li>
            <a title="Counselling and coaching on the Costa Blanca in Spain" href="mailto:lynda&#064;expatmentors.com">
                <img src="../_a_images/envelop-top.svg" /><span>lynda&#064;expatmentors.com</span>
            </a>
        </li>
        <li>
            <a title="Counselling and coaching on the Costa Blanca in Spain" href="tel:447555070467">
                <img src="../_a_images/phone-top.svg" /></i><span>+44 7555 070 467</span>
            </a>
        </li>
        <li>
            <a title="Counselling and coaching on the Costa Blanca in Spain" href="tel:34647356945" target="_blank">
                <img src="../_a_images/whatsapp-top.svg" /><span>+34 647 356 945</span>
            </a>
        </li>
    </ul>
</div>