<div class="contacts-white">
<ul class="contact-icons">
<li><a title="Counselling and coaching on the Costa Blanca in Spain" href="mailto:lynda&#064;expatmentors.com"><i class="fas fa-envelope"></i>&nbsp;<span>lynda&#064;expatmentors.com</span></font></a></li>
<li><a title="Counselling and coaching on the Costa Blanca in Spain" href="tel:447555070467"><i class="fas fa-phone"></i>&nbsp;<span>+44 7555 070 467</span></a></li>
<li><a title="Counselling and coaching on the Costa Blanca in Spain" href="tel:34647356945" target="_blank"><i class="fab fa-whatsapp"></i>&nbsp;<span>+34 647 356 945</span></a></li>
</ul>
</div>