<div class="footer contact-footer">
    <footer>
        <p class="text-white text-center py-4">
        Copyright &copy; <?php echo date("Y"); ?> &nbsp; <a title="Counselling and coaching on the Costa Blanca in Spain" href="https://www.expatmentors.com/" class="text-white">Expat Mentors</a> &nbsp;  All Rights Reserved.<br>
        Hosted by <a title="Website hosting and expert search engine optimisation from www.ForwardWebsites.com " class="text-white" target="_blank" href="https://www.ForwardWebsites.com">Forward Websites</a>
        </p>
    </footer>
</div>