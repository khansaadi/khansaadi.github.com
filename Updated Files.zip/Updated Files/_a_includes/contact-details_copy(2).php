<ul class="contact-icons">
  <li><a title="Counselling and coaching on the Costa Blanca in Spain" href="mailto:lynda&#064;expatmentors.com"><i class="fas fa-envelope"></i>&nbsp;lynda&#064;expatmentors.com</a></li>
  <li><a title="Counselling and coaching on the Costa Blanca in Spain" href="tel:447555070467"><i class="fas fa-phone"></i>&nbsp;+44 7555 070 467</a></li>
  <li><a title="Counselling and coaching on the Costa Blanca in Spain" href="tel:34647356945" target="_blank"><i class="fab fa-whatsapp"></i>&nbsp;+34 647 356 945</a></li>
</ul>