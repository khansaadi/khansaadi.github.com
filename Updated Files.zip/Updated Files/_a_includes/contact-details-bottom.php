<div class="contacts-bottom-of-main-text">
    <ul class="contact-icons">
        <li>
            <a title="Counselling and coaching on the Costa Blanca in Spain" href="mailto:lynda&#064;expatmentors.com">
                <img src="../_a_images/envelop-footer.svg" /><span>lynda&#064;expatmentors.com</span>
            </a>
        </li>
        <li>
            <a title="Counselling and coaching on the Costa Blanca in Spain" href="tel:447555070467">
                <img src="../_a_images/phone-footer.svg" /></i><span>+44 7555 070 467</span>
            </a>
        </li>
        <li>
            <a title="Counselling and coaching on the Costa Blanca in Spain" href="tel:34647356945" target="_blank">
                <img src="../_a_images/whatsapp-footer.svg" /><span>+34 647 356 945</span>
            </a>
        </li>
    </ul>
</div>