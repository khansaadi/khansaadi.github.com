vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|17 Oct 2022 10:42:55 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|DESKTOP-5FRR1NR\\Doug
vti_modifiedby:SR|DESKTOP-5FRR1NR\\Doug
vti_timecreated:TR|01 Aug 2021 16:03:02 -0000
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|17 Oct 2022 10:28:21 -0000
vti_cacheddtm:TX|17 Oct 2022 10:42:55 -0000
vti_filesize:IR|2681
vti_cachedlinkinfo:VX|H|https://www.expatmentors.com/ H|https://www.expatmentors.com/ H|https://www.expatmentors.com/meet-lynda/ H|https://www.expatmentors.com/workplace/ H|https://www.expatmentors.com/counselling-and-coaching/ H|https://www.expatmentors.com/healing/ H|https://www.expatmentors.com/emotion-code/ H|https://www.expatmentors.com/contact-lynda
vti_cachedsvcrellinks:VX|NHSS|https://www.expatmentors.com/ NHSS|https://www.expatmentors.com/ NHSS|https://www.expatmentors.com/meet-lynda/ NHSS|https://www.expatmentors.com/workplace/ NHSS|https://www.expatmentors.com/counselling-and-coaching/ NHSS|https://www.expatmentors.com/healing/ NHSS|https://www.expatmentors.com/emotion-code/ NHSS|https://www.expatmentors.com/contact-lynda
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
