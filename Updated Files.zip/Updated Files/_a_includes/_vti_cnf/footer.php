vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|31 Oct 2022 15:00:18 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|DESKTOP-5FRR1NR\\Doug
vti_modifiedby:SR|DESKTOP-5FRR1NR\\Doug
vti_timecreated:TR|01 Aug 2021 16:03:28 -0000
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|31 Oct 2022 14:59:58 -0000
vti_cacheddtm:TX|31 Oct 2022 15:00:18 -0000
vti_filesize:IR|545
vti_cachedlinkinfo:VX|H|https://www.expatmentors.com/ H|https://www.ForwardWebsites.com
vti_cachedsvcrellinks:VX|NHSS|https://www.expatmentors.com/ NHSS|https://www.ForwardWebsites.com
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
