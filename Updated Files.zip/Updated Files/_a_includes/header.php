<?php $currentPage = basename($_SERVER['PHP_SELF']); ?>
<div class="navigation-bar bg-light start-header start-style">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a title="Counselling and coaching on the Costa Blanca in Spain" class="navbar-brand" href="https://www.expatmentors.com/">Expat <span style="color: #FEA855;">Mentors</span>
                </a> 
                <button aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-target="#navbarSupportedContent" data-toggle="collapse" type="button">
                    <span class="navbar-toggler-icon"></span>
                </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-auto py-4 py-md-0">
                            <li class="nav-item <?php if ($currentPage == '') {echo 'active';} ?>">
                                <a title="Counselling and coaching on the Costa Blanca in Spain" class="nav-link" href="https://www.expatmentors.com/">Home</a>
                            </li>
                            <li class="nav-item <?php if ($currentPage == 'about-lynda') {echo 'active';} ?>">
                                <a title="Counselling and coaching on the Costa Blanca in Spain" class="nav-link" href="../meet-lynda/">Meet Lynda</a>
                            </li>
                            <li class="nav-item <?php if ($currentPage == 'workplace') {echo 'active';} ?>">
                                <a title="Workplace - how to improve it by Lynda Brettle" class="nav-link" href="../workplace/">Workplace</a>
                            </li>
                            <li class="nav-item <?php if ($currentPage == 'counselling-and-coaching') {echo 'active';} ?>">
                                <a title="Counselling and coaching on the Costa Blanca in Spain" class="nav-link" href="../counselling-and-coaching/">Counselling and Coaching</a>
                            </li>
                            <li class="nav-item <?php if ($currentPage == 'healing.php') {echo 'active';} ?>">
                                <a title="Counselling and coaching on the Costa Blanca in Spain" class="nav-link" href="../healing/">Healing</a>
                            </li>
                            <li class="nav-item <?php if ($currentPage == 'emotion-code.php') {echo 'active';} ?>">
                                <a title="Emotion Code - Certified Practitioner" class="nav-link" href="../emotion-code/">Emotion and Body Code</a>
                            </li>
                            <li class="nav-item <?php if ($currentPage == 'contact-lynda') {echo 'active';} ?>">
                                <a title="Counselling and coaching on the Costa Blanca in Spain" class="nav-link" href="../contact-lynda">Contact Lynda</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </div>
</div>