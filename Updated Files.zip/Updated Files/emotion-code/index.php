<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<meta content=" width=device-width, initial-scale=1" name="viewport" />
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	<title>Emotion and Body Code | Expat Mentors</title>
	<meta name="description" content="Offering life coaching, personal counselling and emotional healing at home or away. Helping expatriates handle the psychological and stressful aspects of life abroad." />
	<meta name="keywords" content="Expat living, life coaching, counselling and healing, Spain, Costa Blanca, Wellness, mentoring, Brains at the Border, Lynda Brettle" />
	<!-- >>> Bootstrap 4 | Front End Framework <<< -->
	<!-- <link rel="stylesheet" href="/font-awesome/css/all.css" /> -->
	<!-- >>> Fontawesome 5 | Used for icons <<< -->
	<!-- <link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" href="/cookienoticepro/style/cookienoticepro.style.css"> -->
	<link rel="stylesheet" href="/style.css" />
</head>

<body>
	<div class="overlay">
		<!-- >>>>>>>>>>>>>>> NAVBAR <<<<<<<<<<<<<<<<< -->
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/header.php'); ?>
		<!-- >>>>>>>>>>>>>>>>> HERO BANNER <<<<<<<<<<<<<<<<<<< -->
		<div class="hero-banner-animated">
			<div class="section full-height">
				<div class="absolute-center">
					<div class="section">
						<div class="container">
							<div class="row">
								<div class="col-12">
									<h1 class="text-white">
										<div class="heading-word-wrap">
											<span>W</span> 
											<span>h</span> 
											<span>a</span>
											<span>t</span>
										</div>
										&nbsp;
										<div class="heading-word-wrap">
											<span>a</span> 
											<span>r</span> 
											<span>e</span>
										</div>
										&nbsp;
										<div class="heading-word-wrap">
											<span>t</span> 
											<span>h</span> 
											<span>e</span>
										</div>
										<br>
										<div class="heading-word-wrap">
											<span>E</span> 
											<span>m</span> 
											<span>o</span> 
											<span>t</span> 
											<span>i</span> 
											<span>o</span> 
											<span>n</span>
										</div>
										&nbsp;
										<div class="heading-word-wrap">
											<span>a</span> 
											<span>n</span> 
											<span>d</span>
										</div>
										<br>
										<div class="heading-word-wrap">
											<span>B</span> 
											<span>o</span> 
											<span>d</span> 
											<span>y</span>
										</div>
										&nbsp;
										<div class="heading-word-wrap">
											<span>C</span> 
											<span>o</span> 
											<span>d</span> 
											<span>e</span> 
											<span>s</span> 
											<span>?</span>
										</div>
									</h1>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="social-icons">
					<ul>
						<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/contact-details-top.php'); ?>
					</ul>
				</div>
			</div>
		</div>

		<div class="my-5 py-5"></div>

		<!-- >>>>>>>>>>>>>>>>> MAIN CONTENT <<<<<<<<<<<<<<<<<<< -->

		<div class="body-content">
			<div class="container-fluid">
				<div class="content-area">
					<div class="direction">
						<p>
							<a title="Life Coaching with the Emotion Code and Body Code" href="https://www.expatmentors.com/">Home</a> / Emotion and Body Code
						</p>
					</div>
					<div class="about-lynda">
						<div class="row py-3">
							<div class="col-lg-3 my-auto">
								<div class="profile">
									<img alt="Lynda's Profile Picture" class="img-fluid" src="../_a_images/emotion-code-001.jpg">
								</div>
							</div>
							<div class="col-lg-9 my-auto">
								<div class="text">
									<p>Created in the USA by holistic chiropractor and teacher Dr Bradley Nelson, the Emotion Code is designed to help you:</p>
									<ul class="text-left list-style-none">
										<li><strong>- Resolve physical discomfort </strong></li>
										<li><strong>- Ease emotional wounds </strong></li>
										<li><strong>- Conquer self-doubt</strong></li>
										<li><strong>- Restore love to relationships</strong></li>
										<li><strong>- Break cycles of self-sabotage</strong></li>
									</ul>
								</div>
							</div>
							<div class="col-lg-12 pt-3">
								<p>
									Dr Nelson discovered that his patients´ aches and pains were often associated
									with "Trapped Emotions" (negative energy) in the body. The premise is that this
									energy can exert an influence on physical tissues of the body causing acute
									discomfort and potential disease. The release of the "emotional baggage" can
									restore our physical and emotional balance so that we can live healthier and happier lives!
								</p>
								<p class="mb-0">
									<strong>What happens in a session?</strong>
								</p>
								<p class="mb-0">
									It is not at all like a counselling or therapy session. There is no need for
									long discussions about issues.
								</p>
								<ul class="text-left list-style-none">
									<li>- Muscle Testing a form of biofeedback, taps into the knowledge stored in
								your subconscious mind.</li>
									<li>- Yes or No answers to questions allows the practitioner to assess your
								body's responses</li>
									<li>- Trapped Emotions are often identified. These energies may affect physical
								and emotional wellness.</li>
									<li>- Energy is released using magnetic fields and the principles of ancient Chinese medicine.</li>
								</ul>
								<p>
									Many clients have reported experiencing immediate relief after their first
									session! Most of us have hundreds of Trapped Emotions and clearing these will likely take multiple sessions.
								</p>
								<p>
									Lynda is a certified Emotion Code Practitioner - just contact her on for further information and / or to book a session, which can be held in person or remotely via Skype/Zoom
								</p>
								<p>
									Lynda also works as a certified practitioner with the BODY CODE which incorporates the Emotion Code.
									<img alt="Emotion Code and Body Code from the Expat Mentors" class="img-float" src="../_a_images/body-code-expat-mentors.png" align="right">This is an expanded, and more detailed, patented energy balancing system intended to help uncover the root causes of physical discomfort, sickness and suffering. It provides the opportunity to delve even deeper, and with broader scope, to identify and reset the imbalances which can underlie many troubling conditions, thus enabling the body's own amazing capacity for self - healing to occur quickly and with maximum effect.
									Using a very similar de-coding system, a Body Code session (which incorporates the Emotion Code) goes even further and can help identify and correct physical misalignments and imbalances – often these also have an underlying emotional cause. The Body Code covers six areas:
								</p>		
								<ul class="text-left list-style-none">
									<li>- Emotional Wellness</li>
									<li>- Body System Balance</li>
									<li>- Toxin Resolution</li>
									<li>- Pathogen Resolution</li>
									<li>- Structural Balance</li>
									<li>- Nutrition and Lifestyle</li>
								</ul>
								<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/contact-details-bottom.php'); ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- >>>>>>>>>>>>>>> FOOTER <<<<<<<<<<<<<<<<< -->

	<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/footer.php'); ?>


	<!-- >>> JQUERY <<< -->
	<script src="/jquery/jquery.min.js"></script>
	<script src="/cookienoticepro/cookienoticepro.script.js"></script>

	<script>
		$(document).ready(function() {
			// Initialize cookie consent banner
			cookieNoticePro.init();
		});

		// IMPORTANT: If you are not showing cookie preferences selection menu,
		// then you can remove the below function
		const injectScripts = () => {
			// Example: Google Analytics
			if (cookieNoticePro.isPreferenceAccepted("analytics") === true) {
				console.log("Analytics Scripts Running....");
			}

			// Example: Google Adwords cookie, DoubleClick, Remarketing pixels, Social Media cookies
			if (cookieNoticePro.isPreferenceAccepted("marketing") === true) {
				console.log("Marketing Scripts Running....");
			}

			// Example: Remember password, language, etc
			if (cookieNoticePro.isPreferenceAccepted("preferences") === true) {
				console.log("Preferences Scripts Running....");
			}
		}
	</script>
	<!-- >>> Bootstrap | Front End Framework <<< -->
	<script src="/bootstrap/js/bootstrap.min.js"></script>
	<!-- >>> CUSTOM JS <<< -->
	<script src="/js/script.js"></script>
</body>

</html>