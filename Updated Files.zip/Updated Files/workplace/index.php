<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	<title>Workplace | Expat Mentors</title>
	<meta name="description" content="Offering life coaching, personal counselling and emotional healing at home or away. Helping expatriates handle the psychological and stressful aspects of life abroad." />
	<meta name="keywords" content="Expat living, life coaching, counselling and healing, Spain, Costa Blanca, Wellness, mentoring, Brains at the Border, Lynda Brettle" />
	<!-- >>> Bootstrap 4 | Front End Framework <<< -->
	<!-- <link rel="stylesheet" href="/font-awesome/css/all.css" /> -->
	<!-- >>> Fontawesome 5 | Used for icons <<< -->
	<!-- <link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" href="/cookienoticepro/style/cookienoticepro.style.css"> -->
	<link rel="stylesheet" href="/style.css" />
</head>

<body>
	<div class="overlay">
		<!-- >>>>>>>>>>>>>>> navbar <<<<<<<<<<<<<<<<< -->
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/header.php'); ?>

		<!-- >>>>>>>>>>>>>>>>> HERO BANNER <<<<<<<<<<<<<<<<<<< -->

		<div class="hero-banner-animated">
			<div class="section full-height">
				<div class="absolute-center">
					<div class="section">
						<div class="container">
							<div class="row">
								<div class="col-12">
									<h1 class="text-white">
										<div class="heading-word-wrap">
											<span>W</span> 
											<span>o</span> 
											<span>r</span> 
											<span>k</span> 
											<span>p</span> 
											<span>l</span> 
											<span>a</span> 
											<span>c</span> 
											<span>e</span> 
										</div>
									</h1>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="social-icons">
					<ul>
						<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/contact-details-top.php'); ?>
					</ul>
				</div>
			</div>
		</div>

		<div class="my-5 py-5"></div>

		<!-- >>>>>>>>>>>>>>>>> MAIN CONTENT <<<<<<<<<<<<<<<<<<< -->

		<div class="body-content">
			<div class="container-fluid">
				<div class="content-area">
					<div class="direction">
						<p>
							<a title="Counselling and coaching on the Costa Blanca in Spain" href="https://www.expatmentors.com/">Home</a> / Workplace
						</p>
					</div>
					<div class="about-lynda">
						<div class="row">
							<div class="col-lg-3">
								<div class="profile">
									<img alt="Lynda Brettle - Coaching and Counselling - World-Wide" class="img-fluid" src="../_a_images/workplace-lynda-brettle-1.png" />
								</div>
							</div>
							<div class="col-lg-9 my-auto">
								<div class="text">
									<p>
										Lynda provides financial resource management support to some small businesses as well as ad hoc Spanish language translation and interpretation services.
										In addition, if you have a number of people needing to learn a new language for the first time you may be interested in her Spanish for complete beginners and
										Half Day Workshop in Confidence Building for First Time Learners of any Foreign Language - removing the fear factor and making it fun!
									</p>
								</div>
							</div>
						</div>
						<p>
							<b>1 - 2 day Workshop Training in Essential Management Skills</b> - whether you are developing a team of staff in the hospitality sector, a group of charity volunteers, or are running a new retail outlet or salon or repair workshop, you will want your
							employees and colleagues to be motivated, organised, reliable and handling time and resources efficiently. In addition, you want to ensure they are able meet the targets you set
							as well as being confident and competent in their sales and customer service roles. Presentation and interpersonal skills, cultural awareness and the ability to handle difficult people
							(whether clients or co- workers!) is a great asset. This workshop is aimed at training inexperienced new recruits, and other less experienced staff taking on a new supervisory role.
							By the end of the course participants will be able to:
							- Use a Framework for effective management
							- Set goals, objectives, strategy and KPIs (key performance indicators (
							- Prioritise and schedule work effectively
							- Manage Meetings
							- Motivate and monitor staff
							- Create employed engagement
							- Develop personal resilience.
						</p>
						<p>
							<b>Half-day Workshop in Developing Resilience</b> - this module is included in the Essential Management Skills training and can also be taken separately.
							The aim is to help participants acquire an ability to cope with change, the challenges, problems and set-backs faced in life and to become stronger because of them.
							Resilience draws on various sources of help, including rational thinking skills, physical and emotional health and our relationships with those around us.
							The workshop enables participants to differentiate between negative and positive thinking, challenge the way they think, equip themselves with tools to build resilience
							Develop the emotional intelligence and listening skills in order to help others.
						</p>
						<p>
							<b>Occupational Wellness</b> - the welfare of staff is a key factor in your overall strength as a business too. It can help boost morale to offer a wellness programme as part of the terms and conditions of employment.
							A perfect solution for a small business is to offer your team access to the holistic Emotion Code and Body Code sessions offered by Lynda for both emotional and physical wellbeing.
							Many of us are in an unbalanced state. Few would honestly claim to feel 100% well (physically, emotionally and spiritually). But while imbalance is extremely common and can affect an
							individual's performance and wellbeing, it can also be extremely easy to resolve. Sessions can be offered via Skype, Zoom etc at times to suit wherever your people are located.
							Please do consider it, check out the Emotion and Body Code page for more details and get in touch for a free personal online demonstration of the technique - or group workshop!
						</p>
						<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/contact-details-bottom.php'); ?>
					</div>
				</div>
			</div>
		</div>

		<!-- >>>>>>>>>>>>>>> FOOTER <<<<<<<<<<<<<<<<< -->
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/footer.php'); ?>
	</div>

	<!-- >>> JQUERY <<< -->
	<script src="/jquery/jquery.min.js"></script>
	<script src="/cookienoticepro/cookienoticepro.script.js"></script>

	<script>
		$(document).ready(function() {
			// Initialize cookie consent banner
			cookieNoticePro.init();
		});

		// IMPORTANT: If you are not showing cookie preferences selection menu,
		// then you can remove the below function
		const injectScripts = () => {
			// Example: Google Analytics
			if (cookieNoticePro.isPreferenceAccepted("analytics") === true) {
				console.log("Analytics Scripts Running....");
			}

			// Example: Google Adwords cookie, DoubleClick, Remarketing pixels, Social Media cookies
			if (cookieNoticePro.isPreferenceAccepted("marketing") === true) {
				console.log("Marketing Scripts Running....");
			}

			// Example: Remember password, language, etc
			if (cookieNoticePro.isPreferenceAccepted("preferences") === true) {
				console.log("Preferences Scripts Running....");
			}
		}
	</script>
	<!-- >>> Bootstrap | Front End Framework <<< -->
	<script src="/bootstrap/js/bootstrap.min.js"></script>

	<!-- >>> CUSTOM JS <<< -->
	<script src="/js/script.js"></script>
</body>

</html>