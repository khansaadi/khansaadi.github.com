vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|13 Oct 2022 12:37:45 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|DESKTOP-5FRR1NR\\Doug
vti_modifiedby:SR|DESKTOP-5FRR1NR\\Doug
vti_timecreated:TR|01 Aug 2021 15:57:26 -0000
vti_title:SR|About Lynda | Expat Mentors
vti_nexttolasttimemodified:TR|23 Sep 2022 11:16:38 -0000
vti_cacheddtm:TX|13 Oct 2022 12:37:45 -0000
vti_filesize:IR|8761
vti_cachedtitle:SR|About Lynda | Expat Mentors
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|/font-awesome/css/all.css Q|/bootstrap/css/bootstrap.min.css Q|/cookienoticepro/style/cookienoticepro.style.css Q|/style.css H|https://www.expatmentors.com/ S|/_a_images/lynda-profile.jpg H|https://www.expatmentors.com/book/ H|https://www.amazon.co.uk/Brains-Border-Number-Travel-Book-ebook/dp/B08BRJ5939/ref=sr_1_1 H|https://www.amazon.es/Brains-at-Border-Lynda-Brettle/dp/B08BRHDMNM/ref=sr_1_1 S|/_a_images/about-cma.jpg H|https://www.expatmentors.com/counselling-and-coaching/ H|https://www.expatmentors.com/counselling-and-coaching/ H|https://www.expatmentors.com/emotion-code/ H|https://www.mumabroad.com H|https://www.rise-empower.com H|https://costa-women.mn.co/ H|https://www.loveyourselfproject.co S|/jquery/jquery.min.js S|/cookienoticepro/cookienoticepro.script.js S|/bootstrap/js/bootstrap.min.js S|/js/script.js
vti_cachedsvcrellinks:VX|NQUS|file:///font-awesome/css/all.css NQUS|file:///bootstrap/css/bootstrap.min.css NQUS|file:///cookienoticepro/style/cookienoticepro.style.css NQUS|file:///style.css NHSS|https://www.expatmentors.com/ NSUS|file:///_a_images/lynda-profile.jpg NHSS|https://www.expatmentors.com/book/ NHSS|https://www.amazon.co.uk/Brains-Border-Number-Travel-Book-ebook/dp/B08BRJ5939/ref=sr_1_1 NHSS|https://www.amazon.es/Brains-at-Border-Lynda-Brettle/dp/B08BRHDMNM/ref=sr_1_1 NSUS|file:///_a_images/about-cma.jpg NHSS|https://www.expatmentors.com/counselling-and-coaching/ NHSS|https://www.expatmentors.com/counselling-and-coaching/ NHSS|https://www.expatmentors.com/emotion-code/ NHSS|https://www.mumabroad.com NHSS|https://www.rise-empower.com NHSS|https://costa-women.mn.co/ NHSS|https://www.loveyourselfproject.co NSUS|file:///jquery/jquery.min.js NSUS|file:///cookienoticepro/cookienoticepro.script.js NSUS|file:///bootstrap/js/bootstrap.min.js NSUS|file:///js/script.js
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|viewport \\ width=device-width,\\ initial-scale=1 HTTP-EQUIV=Content-Type text/html;\\ charset=utf-8 description Offering\\ life\\ coaching,\\ personal\\ counselling\\ and\\ emotional\\ healing\\ at\\ home\\ or\\ away.\\ Helping\\ expatriates\\ handle\\ the\\ psychological\\ and\\ stressful\\ aspects\\ of\\ life\\ abroad. keywords Expat\\ living,\\ life\\ coaching,\\ counselling\\ and\\ healing,\\ Spain,\\ Costa\\ Blanca,\\ Wellness,\\ mentoring,\\ Brains\\ at\\ the\\ Border,\\ Lynda\\ Brettle
vti_charset:SR|utf-8
vti_backlinkinfo:VX|
