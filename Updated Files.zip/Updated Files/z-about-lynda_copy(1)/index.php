<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta content=" width=device-width, initial-scale=1" name="viewport" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>About Lynda | Expat Mentors</title>
<meta name="description" content="Offering life coaching, personal counselling and emotional healing at home or away. Helping expatriates handle the psychological and stressful aspects of life abroad."/>
<meta name="keywords" content="Expat living, life coaching, counselling and healing, Spain, Costa Blanca, Wellness, mentoring, Brains at the Border, Lynda Brettle"/>
<!-- >>> Bootstrap 4 | Front End Framework <<< -->
<link rel="stylesheet" href="/font-awesome/css/all.css" />
<!-- >>> Fontawesome 5 | Used for icons <<< -->
<link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" href="/cookienoticepro/style/cookienoticepro.style.css">
<link rel="stylesheet" href="/style.css" />
</head>
<body>
<div class="overlay">
<!-- >>>>>>>>>>>>>>> navbar <<<<<<<<<<<<<<<<< -->
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/header.php'); ?>
<div class="hero-banner-animated">
<div class="section full-height">
<div class="absolute-center">
<div class="section">
<div class="container">
<div class="row">
<div class="col-12">
<h1><span class="para-before about-page">Know More</span>
<br />
<span>A</span><span>b</span><span>o</span><span>u</span><span>t</span>
&nbsp; 
<span>L</span><span>y</span><span>n</span><span>d</span><span>a</span></h1>
<p class="para-after">Offering life coaching, personal counselling and emotional healing at home or
away. Helping expatriates handle the psychological and stressful aspects of life abroad.</p>
</div>
</div>
</div>
</div>
</div>
<div class="social-icons">
<ul>
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/contact-details-top.php'); ?>
</ul>
</div>
</div>
</div>

<div class="my-5 py-5"></div>

<!-- >>>>>>>>>>>>>>>>> MAIN CONTENT <<<<<<<<<<<<<<<<<<< -->

<div class="body-content">
<div class="container-fluid">
<div class="content-area">
<div class="direction">
<p><a title="Counselling and coaching on the Costa Blanca in Spain" href="https://www.expatmentors.com/">Home</a> / About Lynda</p>
</div>
<div class="about-lynda">
<div class="row">
<div class="col-lg-3">
<div class="profile">
<img alt="Lynda Brettles Profile Picture - Coaching and Counselling - World-Wide" class="img-fluid" src="/_a_images/lynda-profile.jpg"/>
</div>
</div>
<div class="col-lg-9 my-auto">
<div class="text">
<p>Originally from the south-east of England, Lynda served for over 20 years with the British Diplomatic Service in management and consular roles with overseas postings in the Far East and South-East Asia, India and Pakistan, the South Pacific, West Africa and Latin America.</p>
<br />
<p>In 2003 Lynda settled in Spain to raise a young family and has been heavily involved with the local expat community. She initially ran a small language studio and newcomers’ groups, and taught Spanish to nervous first-time adult learners, as well as self-development for children and teenagers before moving into more general life coaching, counselling and emotional healing. She has recently “retired” as President of the national mental health charity Samaritans in Spain after having initially joined the Board of Trustees in 2014.</p>
</div>
</div>
</div>
<p>In 2020 Lynda published her first book <a title="Brains At The Border by Lynda Brettle" target="_self" href="https://www.expatmentors.com/book/">Brains at the Border</a> (available in
paperback and kindle from all Amazon marketplaces including <a title="Brains At The Border book by Lynda Brettle from www.Amazon.co.uk" target="_blank" href="https://www.amazon.co.uk/Brains-Border-Number-Travel-Book-ebook/dp/B08BRJ5939/ref=sr_1_1?crid=2672MJ2TPEV2W&keywords=brains+at+the+border&qid=1638477166&sprefix=brains+at+,aps,152&sr=8-1">Amazon.co.uk</a> 
and <a title="Brains At The Border by Lynda Brettle from www.Amazon.es" target="_blank" href="https://www.amazon.es/Brains-at-Border-Lynda-Brettle/dp/B08BRHDMNM/ref=sr_1_1?__mk_es_ES=ÅMÅŽÕÑ&keywords=brains+at+the+border&qid=1638477002&sr=8-1">Amazon.es</a>) about the psychological and emotional impact of expatriate life around
the world. With her background and vast experience, she is ideally placed to support
expat clients in particular. However, she would love to hear from those seeing help whether at home or abroad! Lynda offers personal and confidential lifestyle and health coaching, counselling and emotional healing sessions in person or via phone, Zoom / Skype / WhatsApp calls at convenient times to suit 
you.</p>
<div class="row cmsRow">
<div class="col-lg-3">
<div class="cma">
<img alt="Lynda Brettle - Complementary Medical Association" class="img-fluid" src="/_a_images/about-cma.jpg"/>
</div>
</div>
<div class="col-lg-9 my-auto">
<div class="text">
<p>Lynda is fully registered and insured as a practitioner as an international member of the Complementary Medical Association and certified practitioner with Discover Healing established by the renowned 
Dr Bradley Nelson in the USA. 
</p>
</div>
</div>
</div>
<p>Lynda holds a BA (Hons) degree in Arts and Humanities and is a qualified TEFL
teacher. She holds verified qualifications in Counselling and Social Care, from the
UK Institute of 
<a title="Counselling and Coaching from Lynda Brettle" target="_self" href="https://www.expatmentors.com/counselling-and-coaching/">Counselling</a>, as well as 
<a title="Life Coaching by Lynda Brettle on the Costa Blanca in Spain" target="_self" href="https://www.expatmentors.com/counselling-and-coaching/">Life Coaching</a> 
and Fitness certifications. She is a clairvoyant, and Usui and Angelic Reiki 
(natural energy healing) practitioner. She has been mentored in advanced psychic 
development by medium Alison Wynne Ryder, well-known internationally from 
Canadian TV's &quot;Rescue Mediums&quot; series. Lynda has continued her professional 
development with hypnotherapy work and from summer 2022 is offering Body Code sessions in addition to  the <a title="The New Emotion Code from Lynda Brettle - the coach and counsellor on the Costa Blanca in Spain" target="_self" href="https://www.expatmentors.com/emotion-code/">Emotion Code</a> for the rapid healing of physical imbalances as well as trapped emotions in adults, children . . . and animals!</p>
<br>
<p>MumAbroad (<a target="_blank" href="https://www.mumabroad.com">www.mumabroad.com</a>) lists Lynda as a consultant for their clients with young families relocating to Spain, France, Italy and Germany, She is also a guest speaker for Asia-based RISE (<a target="_blank" href="https://www.rise-empower.com">www.rise-empower.com</a>) creating global connections for women everywhere to become Resilient Inspired Strong and Empowered.  She is the Costa Blanca South social host for Costa Women (<a target="_blank" href="https://costa-women.mn.co/">www.costa-women.mn.co</a>) connecting women both living in and moving to Spain, Lynda is also a presenter/mentor with the Love Yourself Project (<a target="_blank" href="https://www.loveyourselfproject.co">www.loveyourselfproject.com</a>) established in Valencia, Spain in 2020, with global members, promoting wellness in mind, body and business.</p>
</div>
</div>
</div>
</div>

<!-- >>>>>>>>>>>>>>> FOOTER <<<<<<<<<<<<<<<<< -->
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/footer.php'); ?>
</div>

<!-- >>> JQUERY <<< -->
<script src="/jquery/jquery.min.js"></script>
<script src="/cookienoticepro/cookienoticepro.script.js"></script>

<script>
	$(document).ready(function() {
		// Initialize cookie consent banner
		cookieNoticePro.init();
	});
	
	// IMPORTANT: If you are not showing cookie preferences selection menu,
	// then you can remove the below function
	const injectScripts = ()=>{
		// Example: Google Analytics
		if (cookieNoticePro.isPreferenceAccepted("analytics") === true) {
			console.log("Analytics Scripts Running....");
		}

		// Example: Google Adwords cookie, DoubleClick, Remarketing pixels, Social Media cookies
		if (cookieNoticePro.isPreferenceAccepted("marketing") === true) {
			console.log("Marketing Scripts Running....");
		}

		// Example: Remember password, language, etc
		if (cookieNoticePro.isPreferenceAccepted("preferences") === true) {
			console.log("Preferences Scripts Running....");
		}
	} 
</script>
<!-- >>> Bootstrap | Front End Framework <<< -->
<script src="/bootstrap/js/bootstrap.min.js"></script>

<!-- >>> CUSTOM JS <<< -->
<script src="/js/script.js"></script>
</body>
</html>