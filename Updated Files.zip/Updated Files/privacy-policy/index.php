<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta content=" width=device-width, initial-scale=1" name="viewport" />
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Privacy | Lynda Brettle | Expat Mentors</title>
<meta name="description" content="Offering life coaching, personal counselling and emotional healing at home or away. Helping expatriates handle the psychological and stressful aspects of life abroad."/>
<meta name="keywords" content="Expat living, life coaching, counselling and healing, Spain, Costa Blanca, Wellness, mentoring, Brains at the Border, Lynda Brettle"/>

<!-- >>> Bootstrap 4 | Front End Framework <<< -->
<link rel="stylesheet" href="/font-awesome/css/all.css" />

<!-- >>> Fontawesome 5 | Used for icons <<< -->
<link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" href="/cookienoticepro/style/cookienoticepro.style.css">

<link rel="stylesheet" href="/style.css" />
</head>
<body>
<div class="overlay">
<!-- >>>>>>>>>>>>>>> NAVBAR <<<<<<<<<<<<<<<<< -->
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/header.php'); ?>

<!-- >>>>>>>>>>>>>>>>> HERO BANNER <<<<<<<<<<<<<<<<<<< -->

<div class="hero-banner-animated">
<div class="section full-height">
<div class="absolute-center book-page">
<div class="section">
<div class="container">
<div class="row">
<div class="col-12">
<h1><span>C</span> <span>o</span> <span>o</span> <span>k</span> <span>i</span> <span>e</span> <span>s</span>
<br /> 
<span>P</span> <span>r</span> <span>i</span> <span>v</span> <span>a</span> <span>c</span> <span>y</span>
<br />
<span>G</span> <span>D</span> <span>P</span> <span>R</span></h1>
<br />
<br />
</div>
</div>
</div>
</div>
</div>
<div class="social-icons">
<ul>
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/contact-details-top.php'); ?>
</ul>
</div>
</div>
</div>

<div class="my-5 py-5"></div>

<!-- >>>>>>>>>>>>>>>>> MAIN CONTENT <<<<<<<<<<<<<<<<<<< -->

<div class="body-content">
<div class="container-fluid">
<div class="content-area">
<div class="direction">
<p><a title="Counselling and coaching on the Costa Blanca in Spain" href="https://www.expatmentors.com/">Home</a> / Privacy</p>
</div>
<h1>Privacy Policy</h1>
<p>This page is used to inform website visitors regarding our policies with the collection, use, and disclosure of 
personal information if you decide to contact us via the website 
<a title="Counselling and healing on the Costa Blanca in Spain" target="_blank" href="https://www.expatmentors.com/">www.ExpatMentors.com</a> - we do not knowingly collect personal identifiable information direct from persons under the age of 18.  Services 
provided to persons under the age of 18 require consent from a parent or  guardian.</p>
<p>If you choose to use our service, then you agree to the collection and use of information in relation 
to this policy. The 
personal information that we collect is used for providing and improving the service. We will not use or share your information with anyone 
else.</p>
<b>Log Data</b>
<p>We want to inform you that whenever you visit our service, we collect information that your browser sends to us that is called 
log data. This log data may include information such as your computer’s Internet Protocol ("IP") address, browser version, pages of our 
service that you visit, the time and date of your visit, the time spent on those pages, and other statistics.</p>
<b>Cookies</b>
<p>Cookies are files with small amounts of data that is commonly used an anonymous unique identifier. These are sent to your browser from the website that you visit and are stored on your computer’s hard drive.  Our website uses these "cookies" to collection information and to improve our 
service. You have the option to either accept or refuse these cookies, and know when a cookie is being sent to your computer.</p>
<b>Contact Us</b>
<p>If you have any questions or suggestions about our privacy policy, please contact us using the contact form 
on this website or write to us at Expat Mentors Ltd,  2nd Floor, College House, 17 King Edwards Road, London HA4 7AE, UK.</p>
</div>
</div>
</div>
</div>

<!-- >>>>>>>>>>>>>>> FOOTER <<<<<<<<<<<<<<<<< -->
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/footer.php'); ?>
</div>

<!-- >>> JQUERY <<< -->
<script src="/jquery/jquery.min.js"></script>
<script src="/cookienoticepro/cookienoticepro.script.js"></script>

<script>
	$(document).ready(function() {
		// Initialize cookie consent banner
		cookieNoticePro.init();
	});
	
	// IMPORTANT: If you are not showing cookie preferences selection menu,
	// then you can remove the below function
	const injectScripts = ()=>{
		// Example: Google Analytics
		if (cookieNoticePro.isPreferenceAccepted("analytics") === true) {
			console.log("Analytics Scripts Running....");
		}

		// Example: Google Adwords cookie, DoubleClick, Remarketing pixels, Social Media cookies
		if (cookieNoticePro.isPreferenceAccepted("marketing") === true) {
			console.log("Marketing Scripts Running....");
		}

		// Example: Remember password, language, etc
		if (cookieNoticePro.isPreferenceAccepted("preferences") === true) {
			console.log("Preferences Scripts Running....");
		}
	} 
</script>
<!-- >>> Bootstrap | Front End Framework <<< -->
<script src="/bootstrap/js/bootstrap.min.js"></script>

<!-- >>> CUSTOM JS <<< -->
<script src="/js/script.js"></script>
</body>
</html>