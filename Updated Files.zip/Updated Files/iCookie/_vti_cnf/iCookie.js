vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|23 Sep 2022 13:04:10 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|DESKTOP-5FRR1NR\\Doug
vti_modifiedby:SR|DESKTOP-5FRR1NR\\Doug
vti_nexttolasttimemodified:TW|16 Sep 2022 18:51:44 -0000
vti_timecreated:TR|16 Sep 2022 14:51:43 -0000
vti_backlinkinfo:VX|
vti_syncwith_localhost\\m\:\\1a - our websites\\gh - this one/m\:/1a - our websites/gh - this one:TW|16 Sep 2022 14:51:43 -0000
vti_cacheddtm:TX|23 Sep 2022 13:04:10 -0000
vti_filesize:IR|8656
