vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|31 Oct 2022 14:45:48 -0000
vti_author:SR|PC1\\Business
vti_modifiedby:SR|DESKTOP-5FRR1NR\\Doug
vti_nexttolasttimemodified:TW|31 Oct 2022 14:03:50 -0000
vti_timecreated:TR|02 Nov 2005 15:58:53 -0000
vti_title:SR|Lynda Brettle | Expat Mentors
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|dog-walking-group/index_copy-6mar2018.php z-dog-walking/index.php z-dog-walking/index_copy-6mar2018.php
vti_syncwith_localhost\\e\:\\a - our websites\\ti1  - this one/e\:/a - our websites/ti1  - this one:TW|01 Nov 2005 16:42:20 -0000
vti_cacheddtm:TX|31 Oct 2022 14:45:48 -0000
vti_filesize:IR|7233
vti_cachedtitle:SR|Lynda Brettle | Expat Mentors
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|/font-awesome/css/all.css Q|/bootstrap/css/bootstrap.min.css Q|/cookienoticepro/style/cookienoticepro.style.css Q|/style.css H|https://www.expatmentors.com/ H|https://www.amazon.co.uk/dp/B08BRHDMNM S|_a_images/expat-living-book.png H|https://www.amazon.co.uk/dp/B08BRHDMNM/ H|https://www.amazon.co.uk/dp/B08BRHDMNM/ S|/jquery/jquery.min.js S|/cookienoticepro/cookienoticepro.script.js S|/bootstrap/js/bootstrap.min.js S|/js/script.js
vti_cachedsvcrellinks:VX|NQUS|file:///font-awesome/css/all.css NQUS|file:///bootstrap/css/bootstrap.min.css NQUS|file:///cookienoticepro/style/cookienoticepro.style.css NQUS|file:///style.css NHSS|https://www.expatmentors.com/ NHSS|https://www.amazon.co.uk/dp/B08BRHDMNM FSUS|_a_images/expat-living-book.png NHSS|https://www.amazon.co.uk/dp/B08BRHDMNM/ NHSS|https://www.amazon.co.uk/dp/B08BRHDMNM/ NSUS|file:///jquery/jquery.min.js NSUS|file:///cookienoticepro/cookienoticepro.script.js NSUS|file:///bootstrap/js/bootstrap.min.js NSUS|file:///js/script.js
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|viewport width=device-width,\\ initial-scale=1.0 HTTP-EQUIV=Content-Type text/html;\\ charset=utf-8 description Expat\\ living\\ on\\ the\\ Costa\\ Blanca\\ in\\ Spain.\\ \\ Life\\ coaching\\ on\\ the\\ Costa\\ Blanca\\ in\\ Spain.\\ Counselling\\ and\\ healing\\ on\\ the\\ Costa\\ Blanca\\ in\\ Spain. keywords Expat\\ living,\\ life\\ coaching,\\ counselling\\ and\\ healing,\\ Spain,\\ Costa\\ Blanca,\\ Wellness,\\ mentoring,\\ Brains\\ at\\ the\\ Border,\\ Lynda\\ Brettle
vti_charset:SR|utf-8
