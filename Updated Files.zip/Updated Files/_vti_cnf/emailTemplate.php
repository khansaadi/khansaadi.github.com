vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|02 Aug 2021 07:41:10 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|DESKTOP-5FRR1NR\\Doug
vti_modifiedby:SR|DESKTOP-5FRR1NR\\Doug
vti_timecreated:TR|02 Aug 2021 09:11:10 -0000
vti_title:SR|New Form Submission
vti_backlinkinfo:VX|
vti_cacheddtm:TX|02 Aug 2021 07:41:10 -0000
vti_filesize:IR|3864
vti_cachedtitle:SR|New Form Submission
vti_cachedbodystyle:SR|<body style="margin: 0px;">
vti_cachedlinkinfo:VX|Q|https://fonts.googleapis.com/css H|https://www.expatmentors.com/
vti_cachedsvcrellinks:VX|NQSS|https://fonts.googleapis.com/css NHSS|https://www.expatmentors.com/
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=utf-8 description Reset\\ Password\\ Email\\ Template.
vti_charset:SR|utf-8
