vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|24 Nov 2006 18:06:42 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|Doug-PC\\Doug
vti_modifiedby:SR|Doug-PC\\Doug
vti_timecreated:TR|24 Nov 2006 18:06:42 -0000
vti_cacheddtm:TX|24 Nov 2006 18:06:42 -0000
vti_filesize:IR|4214
vti_cachedtitle:SR|Editing index.php
vti_cachedbodystyle:SR|<body>
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Type text/html;\\ charset=utf-8
vti_charset:SR|utf-8
vti_title:SR|Editing index.php
vti_backlinkinfo:VX|
