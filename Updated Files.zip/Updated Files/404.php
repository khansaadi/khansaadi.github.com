<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/top-space.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Horsham</title>
<meta content="text/html; charset=utf-8" http-equiv="content-type">
<meta name="description" content="Horsham">
<meta name="keywords" content="Horsham">
<link href="https://www.HorshamInformation.com" rel="bookmark" title="Horsham">
<meta http-equiv="refresh" content="6;URL=https://www.HorshamInformation.com/">
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/meta-tags.php'); ?>
<link rel="stylesheet" href="/styles.css">
</head>
<body>
<table summary="Horsham in West Sussex">
<tr>
<td>
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/top.php'); ?>
</td>
</tr>
</table>
<table summary="Horsham in West Sussex">
<tr>
<td>
<h3>Error</h3>
</td>
</tr>
</table>
<table summary="Horsham in West Sussex">
<tr>
<td>
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/left.php'); ?>
</td>
<td class="maintextcell">
<p>
Sorry you've come to this page - perhaps the page you were looking 
for is being worked on, or it may have been moved.<br>
<br>
You'll see the home page in a few seconds.
</td>
<td>
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/right.php'); ?>
</td>
</tr>
</table>
<table summary="Horsham in West Sussex">
<tr>
<td>
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/bottom-go-back.php'); ?>
</td>
</tr>
</table>
</body>
</html>