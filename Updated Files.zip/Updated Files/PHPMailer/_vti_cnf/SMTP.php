vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|28 Dec 2019 14:09:56 -0000
vti_extenderversion:SR|6.0.2.5516
vti_author:SR|DESKTOP-5FRR1NR\\Doug
vti_modifiedby:SR|DESKTOP-5FRR1NR\\Doug
vti_timecreated:TR|28 Dec 2019 15:39:56 -0000
vti_backlinkinfo:VX|
vti_cacheddtm:TX|28 Dec 2019 14:09:56 -0000
vti_filesize:IR|44192
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|windows-1252
