<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<meta content=" width=device-width, initial-scale=1" name="viewport" />
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	<title>Healing | Lynda Brettle</title>
	<meta name="description" content="Offering life coaching, personal counselling and emotional healing at home or away. Helping expatriates handle the psychological and stressful aspects of life abroad." />
	<meta name="keywords" content="Expat living, life coaching, counselling and healing, Spain, Costa Blanca, Wellness, mentoring, Brains at the Border, Lynda Brettle" />

	<!-- >>> Bootstrap 4 | Front End Framework <<< -->
	<!-- <link rel="stylesheet" href="/font-awesome/css/all.css" /> -->

	<!-- >>> Fontawesome 5 | Used for icons <<< -->
	<!-- <link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" href="/cookienoticepro/style/cookienoticepro.style.css"> -->

	<link rel="stylesheet" href="/style.css" />
</head>

<body>
	<div class="overlay">
		<!-- >>>>>>>>>>>>>>> NAVBAR <<<<<<<<<<<<<<<<< -->
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/header.php'); ?>

		<!-- >>>>>>>>>>>>>>>>> HERO BANNER <<<<<<<<<<<<<<<<<<< -->

		<div class="hero-banner-animated">
			<div class="section full-height">
				<div class="absolute-center">
					<div class="section">
						<div class="container">
							<div class="row">
								<div class="col-12">
									<h1 class="text-white">
										<div class="heading-word-wrap">
											<span>H</span> 
											<span>e</span> 
											<span>a</span> 
											<span>l</span> 
											<span>i</span>
											<span>n</span> 
											<span>g</span>
										</div>
									</h1>
									<p class="text-white w-100">
										Tough times don't last - Tough People Do!
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="social-icons">
					<ul>
						<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/contact-details-top.php'); ?>
					</ul>
				</div>
			</div>
		</div>

		<div class="my-5 py-5"></div>

		<!-- >>>>>>>>>>>>>>>>> MAIN CONTENT <<<<<<<<<<<<<<<<<<< -->

		<div class="body-content">
			<div class="container-fluid">
				<div class="content-area">
					<div class="direction pb-4">
						<p>
							<a title="Counselling and coaching on the Costa Blanca in Spain" href="https://www.expatmentors.com/">Home</a> / Healing
						</p>
					</div>
					<div class="counselling-and-coaching-detail-content">
						<div class="row">
							<div class="col-lg-12 col-xl-4 pb-4">
								<div class="grid">
									<figure class="effect-roxy">
										<img alt="Counselling and coaching on the Costa Blanca in Spain" src="/_a_images/healing-1.jpg" />
										<figcaption>
											<h2>A Healthy Mind is a Healthy Body</h2>
											<p>Maintain a positive outlook. Our thoughts and feelings can physically
												change our bodies!</p>
										</figcaption>
									</figure>
								</div>
							</div>
							<div class="col-lg-12 col-xl-4 pb-4">
								<div class="grid">
									<figure class="effect-roxy">
										<img alt="Counselling and coaching on the Costa Blanca in Spain" src="/_a_images/healing-2.jpg" />
										<figcaption>
											<h2>A Healthy Body is a Healthy Mind</h2>
											<p>A balanced diet, exercise, good sleep and fresh air all help us stay calm and relaxed.</p>
										</figcaption>
									</figure>
								</div>
							</div>
							<div class="col-lg-12 col-xl-4 pb-4">
								<div class="grid">
									<figure class="effect-roxy">
										<img alt="Counselling and coaching on the Costa Blanca in Spain" src="/_a_images/healing-3.jpg" />
										<figcaption>
											<h2>Energy Healing</h2>
											<p>Energy Healing is one of the most effective practices to clear any
												imbalances and restore / maintain equilibrium.</p>
										</figcaption>
									</figure>
								</div>
							</div>
						</div>
						<div class="text-content healing-page pt-4">
							<p>As the old saying goes, a healthy body is a healthy mind, and increasingly Western
								medicine / science is now beginning to understand more about the Mind-Body
								interaction and the impact our thoughts and beliefs also have on our physical
								health. These findings confirm the teachings, with origins thousands of years ago,
								from other cultures and peoples from the ancient Chinese to Native Americans and
								their holistic remedies and natural energy balancing practices.
							</p>
							<p>You do not need to consider yourself religious or spiritual to benefit from
								traditional Japanese Usui Reiki (or the more modern Angelic Reiki), simply be open
								to receive this gentle and non-invasive treatment. Quantum physics tells us that
								the human body and all things are connected by universal energies. Our natural
								state should be one of balance, but life experiences can often cause imbalances. A
								Reiki therapist can channel life force energy into a client by means of light
								touch, to activate the natural healing processes of the patient's body and restore
								physical and emotional well-being. Please note that Reiki is not an alternative to
								be used instead of standard medical care - it is however a complementary method
								that can be used in support of any current treatment. Reiki can help speed
								recovery, soothe and provide relief of pain at all mental, emotional and physical
								levels and consultants are now also called upon for assistance by doctors
								including the National Health Service in UK. That said, if there are concerns
								about physical symptoms please do consult your usual medical practitioner. 
							</p>
							<p>
								The latest <a title="Emotion Code - Lynda Brettle" target="_self" href="../emotion-code">Emotion Code</a>
								<b>and Body Code techniques</b> described on the following page are also
								non-invasive forms of energy healing. Via simple muscle testing methods to
								connect with the subconscious, trapped emotions can swiftly be identified and
								released to restore balance and calm with the use of healing magnets. As a
								certified practitioner, Lynda can discover and remove negative emotional
								energies that are stuck in your body from past experiences. This can help you
								feel calmer, lighter, more energetic, more creative, more connected to others
								and possibly even help you experience less physical discomfort. The Body Code
								delves deeper and in addition addresses physical imbalances in the body
								including the identification of Nutrition and Lifestyle needs, the release of
								Toxins and Pathogens, the correction of Misalignments in the Circuits and
								Systems (digestive, respiratory, skeletal etc) of the body as well as helping
								with the healing of Organs and Glands. Please get in touch now for a free
								introductory consultation and discover the many benefits!
							</p>
							<div class="testimonial-text pt-5">
								<h1>Suggested further reading about the Mind..Body connection and Energy Healing</h1>
								<ul class="list-style-none">
									<li>
										<a title="Brains At The Border by Lynda Brettle" target="_self" href="https://www.expatmentors.com/book/">Brains at the Border</a> by Lynda Brettle
									</li>
									<li>The Energy Codes by Dr Sue Morter</li>
									<li>The Emotion Code by Dr Bradley Nelson</li>
									<li>Reiki for Life by Penelope Quest</li>
									<li>Change Your Thoughts, Change Your Life by Dr Wayne W Dyer</li>
									<li>Heal Your Life by Louise Hay</li>
									<li>You Are The Placebo by Dr Joe Dispenza</li>
									<li>The Biology of Belief by Bruce H. Lipton PhD</li>
									<li>It's The Thought That Counts - Why Mind Over Matter Really Works by Dr David R. Hamilton</li>
								</ul>
							</div>
							<p class="text-center">
								<strong>Just click on a link below to contact Lynda and book a session now!</strong>
								<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/contact-details-bottom.php'); ?>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/footer.php'); ?>
	</div>
	<!-- >>> JQUERY <<< -->
	<script src="/jquery/jquery.min.js"></script>
	<script src="/cookienoticepro/cookienoticepro.script.js"></script>

	<script>
		$(document).ready(function() {
			// Initialize cookie consent banner
			cookieNoticePro.init();
		});

		// IMPORTANT: If you are not showing cookie preferences selection menu,
		// then you can remove the below function
		const injectScripts = () => {
			// Example: Google Analytics
			if (cookieNoticePro.isPreferenceAccepted("analytics") === true) {
				console.log("Analytics Scripts Running....");
			}

			// Example: Google Adwords cookie, DoubleClick, Remarketing pixels, Social Media cookies
			if (cookieNoticePro.isPreferenceAccepted("marketing") === true) {
				console.log("Marketing Scripts Running....");
			}

			// Example: Remember password, language, etc
			if (cookieNoticePro.isPreferenceAccepted("preferences") === true) {
				console.log("Preferences Scripts Running....");
			}
		}
	</script>

	<!-- >>> Bootstrap | Front End Framework <<< -->
	<script src="/bootstrap/js/bootstrap.min.js"></script>

	<!-- >>> CUSTOM JS <<< -->
	<script src="/js/script.js"></script>
</body>

</html>