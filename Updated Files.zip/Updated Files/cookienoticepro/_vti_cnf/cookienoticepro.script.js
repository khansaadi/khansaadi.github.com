vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|23 Sep 2022 17:29:52 -0000
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|cookienoticepro/index.html
vti_author:SR|DESKTOP-5FRR1NR\\Doug
vti_modifiedby:SR|DESKTOP-5FRR1NR\\Doug
vti_nexttolasttimemodified:TW|23 Sep 2022 17:28:02 -0000
vti_timecreated:TR|23 Sep 2022 13:11:32 -0000
vti_cacheddtm:TX|23 Sep 2022 17:29:52 -0000
vti_filesize:IR|19966
