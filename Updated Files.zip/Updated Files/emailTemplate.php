<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
	<title>New Form Submission</title>
	<meta content="Reset Password Email Template." name="description">
</head>
<body style="margin: 0px;">
	<table bgcolor="white" border="0" cellpadding="0" cellspacing="0" style="@import url('https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&subset=devanagari,latin-ext');" width="100%">
		<tr>
			<td>
				<table align="center" border="0" cellpadding="0" cellspacing="0" style="background-color: white; max-width:670px; margin:0 auto;" width="100%">
					<tr><td style="height:80px;">&nbsp;</td></tr>
					<tr>
						<td style="text-align:center;">
							<h1 style="color:#1e1e2d; font-weight:500; margin:0;font-size:35px;font-family:Poppins;">Expat <span style="color: #FEA855;">Mentors</span></h1>
						</td>
					</tr>
					<tr><td style="height:20px;">&nbsp;</td></tr>
					<tr>
						<td>
							<table align="center" border="0" cellpadding="0" cellspacing="0" style="max-width:670px;background: rgb(245, 245, 245); border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);" width="95%">
                                <tr><td style="height:60px;">&nbsp;</td></tr>
								<tr>
									<td style="padding:0 30px;">
										<h1 style="color:#1e1e2d; font-weight:500; margin:0;font-size:25px;font-family:Poppins;">You have New Form Submission</h1><span style="display:inline-block; vertical-align:middle; margin:29px 0 26px; border-bottom:1px solid #cecece; width:180px;"></span>
										<p style="font-family:Poppins; color:#455056; font-size:15px;line-height:24px; margin:0;">Hi Lynda! Someone submit the contact form on <a href="https://www.expatmentors.com/" style="color: #FEA855;">Expatmentors.com</a>, The details are following, you can contact him/her by using this info.</p>
										<p style="font-family:Poppins; color:#000; font-weight: 600; font-size:15px;line-height:24px; margin:0; padding-top: 40px; padding-bottom: 10px; text-align: left; padding-left: 10% ; padding-right: 10% ;">Name:</p>
										<p style="font-family:Poppins; text-align: left; color:#455056; font-size:15px;line-height:24px; margin:0 ; padding-left: 10% ; padding-right: 10% ; padding-bottom:20px;">%username%</p>
										<p style="font-family:Poppins; color:#000; font-weight: 600; font-size:15px;line-height:24px; margin:0; padding-bottom: 10px; text-align: left; padding-left: 10% ; padding-right: 10% ;">Email:</p>
										<p style="font-family:Poppins; text-align: left; color:#FEA855; font-size:15px;line-height:24px; margin:0 ; padding-left: 10% ; padding-right: 10% ; padding-bottom:20px;"><a href="" style="color:#FEA855;">%useremail%</a></p>
										<p style="font-family:Poppins; color:#000; font-weight: 600; font-size:15px;line-height:24px; margin:0; padding-bottom: 10px; text-align: left; padding-left: 10% ; padding-right: 10% ;">Message:</p>
										<p style="font-family:Poppins; text-align: left; color:#455056; font-size:15px;line-height:24px; margin:0 ; padding-left: 10% ; padding-right: 10% ; padding-bottom:20px;">%usermessage%</p>
									</td>
								</tr>
								<tr><td style="height:60px;">&nbsp;</td></tr>
							</table>
						</td>
					</tr>
					<tr><td style="height:20px;">&nbsp;</td></tr>
					<tr>
						<td style="text-align:center;">
							<p style="font-family:Poppins;font-size:14px; color:#000; line-height:18px; margin:0 0 0;">&copy; <a style="color:#000;">www.expatmentors.com</a></p>
						</td>
					</tr>
					<tr><td style="height:80px;">&nbsp;</td></tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>