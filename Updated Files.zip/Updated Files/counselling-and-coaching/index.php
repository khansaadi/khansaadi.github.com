<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<meta content=" width=device-width, initial-scale=1" name="viewport" />
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	<title>Counselling and Coaching | Lynda Brettle</title>
	<meta name="description" content="Offering life coaching, personal counselling and emotional healing at home or away. Helping expatriates handle the psychological and stressful aspects of life abroad." />
	<meta name="keywords" content="Expat living, life coaching, counselling and healing, Spain, Costa Blanca, Wellness, mentoring, Brains at the Border, Lynda Brettle" />
	<link rel="stylesheet" href="/style.css" />
</head>

<body>
	<div class="overlay">
		<!-- >>>>>>>>>>>>>>> NAVBAR <<<<<<<<<<<<<<<<< -->
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/header.php'); ?>
		<!-- >>>>>>>>>>>>>>>>> HERO BANNER <<<<<<<<<<<<<<<<<<< -->
		<div class="hero-banner-animated">
			<div class="section full-height">
				<div class="absolute-center counselling-and-coaching-page">
					<div class="section">
						<div class="container">
							<div class="row">
								<div class="col-12">
									<h1 class="text-white">
										<span class="para-before">What is the difference?</span>
										<br />
										<div class="heading-word-wrap">
											<span>C</span> 
											<span>o</span> 
											<span>u</span> 
											<span>n</span> 
											<span>s</span>
											<span>e</span> 
											<span>l</span> 
											<span>l</span> 
											<span>i</span> 
											<span>n</span>
											<span>g</span>
										</div>
										&nbsp;
										<div class="heading-word-wrap">
											<span>a</span> 
											<span>n</span> 
											<span>d</span>
										</div>
										<br />
										<div class="heading-word-wrap">
											<span>C</span> 
											<span>o</span> 
											<span>a</span> 
											<span>c</span> 
											<span>h</span>
											<span>i</span> 
											<span>n</span> 
											<span>g</span>
										</div>
									</h1>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="social-icons">
					<ul>
						<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/contact-details-top.php'); ?>
					</ul>
				</div>
			</div>
		</div>
		<div class="my-5 py-5"></div>

		<!-- >>>>>>>>>>>>>>>>> MAIN CONTENT <<<<<<<<<<<<<<<<<<< -->

		<div class="body-content">
			<div class="container-fluid">
				<div class="content-area">
					<div class="direction pb-3">
						<p>
							<a title="Counselling and coaching on the Costa Blanca in Spain" href="https://www.expatmentors.com/">Home</a> / Counselling and Coaching
						</p>
					</div>
					<div class="counselling-and-coaching-detail-content">
						<h1 class="pb-3">Counselling and Coaching</h1>
						<p class="text-center pb-4">What is the difference?</p>
						<div class="row">
							<div class="col-lg-12 col-xl-4 pb-4">
								<div class="grid">
									<figure class="effect-roxy">
										<img alt="Counselling and coaching on the Costa Blanca in Spain" src="/_a_images/counselling-and-coaching-1.jpg" />
										<figcaption>
											<h2>Life <span>coaching</span></h2>
											<p>Life coaching is a co-creative process in which the coach helps ...</p>
										</figcaption>
									</figure>
								</div>
							</div>
							<div class="col-lg-12 col-xl-4 pb-4">
								<div class="grid">
									<figure class="effect-roxy">
										<img alt="Counselling and coaching on the Costa Blanca in Spain" src="/_a_images/counselling-and-coaching-2.jpg" />
										<figcaption>
											<h2><span>Mentoring</span></h2>
											<p>Mentoring involves the transfer of skills and acquired wisdom ...</p>
										</figcaption>
									</figure>
								</div>
							</div>
							<div class="col-lg-12 col-xl-4 pb-4">
								<div class="grid">
									<figure class="effect-roxy">
										<img alt="Counselling and coaching on the Costa Blanca in Spain" src="/_a_images/counselling-and-coaching-3.jpg" />
										<figcaption>
											<h2><span>Counselling</span></h2>
											<p>Counselling is a kind of approach adopted to help people resolve ...</p>
										</figcaption>
									</figure>
								</div>
							</div>
						</div>
						<div class="text-content pt-4">
							<p>
								<strong>Life coaching</strong> is a co-creative process in which the coach helps
								the client identify their values and aspirations and create action plans to
								motivate them, overcome any bad habits or procrastination, acquire certain skills
								and effectively manage their time and resources for success, however they define
								that success and wherever they may be located.
							</p>
							<p>
								<strong>Mentoring</strong> involves the transfer of skills and acquired wisdom
								from a more experienced person to a person without the experience. It is
								relationship-based and tends to be informal and longer term. Lynda has the perfect
								range of skills and experience to offer mentoring for expatriates - equipping them
								with the knowledge and skills for living outside of their home country for the
								first time.
							</p>
							<p>
								Both mentoring and life coaching are concerned with enabling an individual to
								achieve certain goals so as to make a positive difference to their personal and/or
								professional lives. Both are results-oriented and go beyond helping identify goals
								to stimulating self - confidence and focus to stay on track.
							</p>
							<p>
								<strong>Counselling</strong> is an approach adopted to help people resolve
								situations and heal emotional wounds. The aim is to identify and address problems
								and unhelpful behaviour patterns which are often subconscious. Talk therapies such
								as Cognitive Behavioural Therapy (CBT) help identify the links between our
								negative thoughts, feelings and behaviour. Changing our thoughts really can help
								us make changes to our feelings and behaviour and enable us to achieve the positive results we desire!
							</p>
							<p>
								Counselling, emotional resilience training and healing can all help with stress
								relief. The release of emotional baggage can restore balance in both mental and
								physical health. Lynda has successfully helped people resolve conflict in work and
								family relationships, and supported individuals handling a broad range of
								difficulties including grief, loss, isolation, lack of confidence, anxiety,
								financial crisis, abuse and bullying, PTSD, chronic pain and ill-health, and the
								impact of autism spectrum issues.
							</p>
							<div class="testimonial-text pt-5">
								<h3 class="pb-4">What Others Say...</h3>
								<div class="fixed-image">
									<div class="inside-content py-4">
										<p class="text-center text-white">A real driving force for change....<br />
											You have been a true rock for me to lean on ......<br />
											Briefing is first rate...........Amazing results.<br />
											Very supportive and good fun sessions too<br />
											I love the common sense approach to everything!...
										</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- >>>>>>>>>>>>>>> FOOTER <<<<<<<<<<<<<<<<< -->
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/footer.php'); ?>
	</div>
	<!-- >>> JQUERY <<< -->
	<script src="/jquery/jquery.min.js"></script>
	<script src="/cookienoticepro/cookienoticepro.script.js"></script>

	<script>
		$(document).ready(function() {
			// Initialize cookie consent banner
			cookieNoticePro.init();
		});

		// IMPORTANT: If you are not showing cookie preferences selection menu,
		// then you can remove the below function
		const injectScripts = () => {
			// Example: Google Analytics
			if (cookieNoticePro.isPreferenceAccepted("analytics") === true) {
				console.log("Analytics Scripts Running....");
			}

			// Example: Google Adwords cookie, DoubleClick, Remarketing pixels, Social Media cookies
			if (cookieNoticePro.isPreferenceAccepted("marketing") === true) {
				console.log("Marketing Scripts Running....");
			}

			// Example: Remember password, language, etc
			if (cookieNoticePro.isPreferenceAccepted("preferences") === true) {
				console.log("Preferences Scripts Running....");
			}
		}
	</script>
	<!-- >>> Bootstrap | Front End Framework <<< -->
	<script src="/bootstrap/js/bootstrap.min.js"></script>
	<!-- >>> CUSTOM JS <<< -->
	<script src="/js/script.js"></script>
</body>

</html>