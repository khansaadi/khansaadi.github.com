<?php ob_start() ?>
<?php
if ($_GET['randomId'] != "QyECnSnnPB3v8vf0aDGH6zO6zjaoSIjy90chjwNewBkekxWGga4Di_tmFmaK6AX8VePc2ZjkSU58eE2sdeW1Ekl0z3D58H208NzRnb2LDVtCizgHErmaL0kgI6Z7lSE4A_Ybm8A9dPvTjPtX25a9MZvGiiLtDLXccM4DhAXPu338A9BTvfkCgouR5UGowsH9Jd2fbO3VdhsPPurCB2WhQ0mh49qzRNJ_7Fa7Kr9XzUJ3oLD984ZmF_orgAtYEjzV") {
    echo "Access Denied";
    exit();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Editing index.php</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style type="text/css">body {background-color:threedface; border: 0px 0px; padding: 0px 0px; margin: 0px 0px}</style>
</head>
<body>
<div align="center">
<script language="javascript">
<!--//
// this function updates the code in the textarea and then closes this window
function do_save() {
	var code =  htmlCode.getCode();
	document.open();
	document.write('<html><form METHOD="POST" name=mform action="http://64.34.199.70:2082/frontend/x/files/savehtmlfile.html"><input type="hidden" name="dir" value="/home/millionl/public_html/members/paypal"><input type="hidden" name="file" value="index.php">Saving&nbsp;....<br /><br ><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><textarea name=page rows=1 cols=1></textarea></form></html>');
	document.close();
	document.mform.page.value = code;
	document.mform.submit();
}
function do_abort() {
	var code =  htmlCode.getCode();
	document.open();
	document.write('<html><form METHOD="POST" name="mform" action="http://64.34.199.70:2082/frontend/x/files/aborthtmlfile.html"><input type="hidden" name="dir" value="/home/millionl/public_html/members/paypal"><input type="hidden" name="file" value="index.php">Aborting Edit&nbsp;....</form></html>');
	document.close();
	document.mform.submit();
}
//-->
</script>
<?php
// make sure these includes point correctly:
include_once ('/usr/local/cpanel/base/3rdparty/WysiwygPro/editor_files/config.php');
include_once ('/usr/local/cpanel/base/3rdparty/WysiwygPro/editor_files/editor_class.php');

// create a new instance of the wysiwygPro class:
$editor = new wysiwygPro();

// add a custom save button:
$editor->addbutton('Save', 'before:print', 'do_save();', WP_WEB_DIRECTORY.'images/save.gif', 22, 22, 'undo');

// add a custom cancel button:
$editor->addbutton('Cancel', 'before:print', 'do_abort();', WP_WEB_DIRECTORY.'images/cancel.gif', 22, 22, 'undo');

$body = '<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title> Order Form </title>
</head>

<body>
<table width="350" border="0" cellspacing="2" cellpadding="0" align="center">
<form method="post" action="paypal2.php">
  <tr>
    <td>First Name </td>
    <td><input type="text" name="fname"></td>
  </tr>
  <tr>
    <td>Last Name </td>
    <td><input type="text" name="lname"></td>
  </tr>
  <tr>
    <td>Address</td>
    <td><input type="text" name="address"></td>
  </tr>
  <tr>
    <td>City</td>
    <td><input type="text" name="city"></td>
  </tr>
  <tr>
    <td>State</td>
    <td><input type="text" name="state"></td>
  </tr>
  <tr>
    <td>Country</td>
    <td><input type="text" name="country"></td>
  </tr>
  <tr>
    <td>Email</td>
    <td><input type="text" name="email"></td>
  </tr>
  <tr>
    <td>Phone</td>
    <td><input type="text" name="phone"></td>
  </tr>
  <tr>
    <td>
		<input type="hidden" name="affiliate" value="">
		<input type="hidden" name="planid" value="<?=$_REQUEST[\'planID\']?>">
	</td>
    <td><input type="submit" name="submit" value=" Submit "></td>
  </tr>
  </form>
</table>

</body>
</html>
';

$editor->set_code($body);

// add a spacer:
$editor->addspacer('', 'after:cancel');

// print the editor to the browser:
$editor->print_editor('100%',450);

?>
</div>
</body>
</html>
<?php ob_end_flush() ?>
