<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
<title>Lynda Brettle | Expat Mentors</title>
<meta name="description" content="Expat living on the Costa Blanca in Spain.  Life coaching on the Costa Blanca in Spain. Counselling and healing on the Costa Blanca in Spain." />
<meta name="keywords" content="Expat living, life coaching, counselling and healing, Spain, Costa Blanca, Wellness, mentoring, Brains at the Border, Lynda Brettle" />

<!-- >>> Bootstrap 4 | Front End Framework <<< -->
<link rel="stylesheet" href="/font-awesome/css/all.css" />

<!-- >>> Fontawesome 5 | Used for icons <<< -->
<link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css" />
<link rel="stylesheet" href="/cookienoticepro/style/cookienoticepro.style.css">

<link rel="stylesheet" href="/style.css" />



</head>
<body>
<div class="overlay">
<!-- >>>>>>>>>>>>>>> NAVBAR <<<<<<<<<<<<<<<<< -->
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/header.php'); ?>

<!-- >>>>>>>>>>>>>>>>> HERO BANNER <<<<<<<<<<<<<<<<<<< -->

<div class="hero-banner-animated">
<div class="section full-height">
<div class="absolute-center">
<div class="section">
<div class="container">
<div class="row">
<div class="col-12">
<h1><span class="para-before">Welcome to</span><br />
<span>E</span> <span>x</span> <span>p</span> <span>a</span>
<span>t</span>
&nbsp; 
<span>M</span> <span>e</span> <span>n</span>
<span>t</span> <span>o</span> <span>r</span> <span>s</span></h1>
<p>Offering life coaching, personal counselling and emotional healing at home or
away. Helping expatriates handle the psychological and stressful aspects of life abroad.</p>
</div>
</div>
</div>
</div>
</div>
<div class="social-icons">
<ul>
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/contact-details-top.php'); ?>
</ul>
</div>
</div>
</div>

<div class="my-5 py-5"></div>

<!-- >>>>>>>>>>>>>>>>> MAIN CONTENT <<<<<<<<<<<<<<<<<<< -->

<div class="body-content">
<div class="container-fluid">
<div class="content-area">
<div class="direction">
<p>Welcome /<a title="Counselling and coaching on the Costa Blanca in Spain" href="https://www.expatmentors.com/">Home</a></p>
</div>
<div class="covid-pandemic">
<i class="fas fa-virus"></i>
<p>The COVID 19 pandemic has caused more people than ever before to seek help.  Are you
feeling stressed? Overwhelmed?  Out of balance mentally or physically? Calming the
mind and developing a positive mental attitude brings great benefit to all aspects
of your life experience wherever you are and whatever your age. You <b>CAN</b> bounce back, heal and thrive!</p>
</div>
<div class="about-lynda">
<div class="row">
<div class="col-lg-3">
<div class="profile">
<img alt="Counselling and coaching on the Costa Blanca in Spain" class="img-fluid" src="_a_images/profile.png"/>
</div>
</div>
<div class="col-lg-9 my-auto">
<div class="text">
<p>Hello and Welcome!</p>
<p>My name is Lynda, and I have a wealth of experience with over thirty-five
years living and working all over the world, dealing with people from every
walk of life and widely diverse cultural backgrounds. Over the past decade I
have gradually moved away from my original career, and organisational
management, into life coaching, mentoring, personal counselling and natural
energy healing of Reiki treatments. I am also pleased to offer the very latest
techniques to clear trapped emotions that often cause or contribute to ongoing
mental distress or even physical ailments. Relief truly can be rapid!</p>
<br>
<p>The international travel and expat lifestyle I enjoyed combined with my
passion for mental health and wellbeing enables me to connect particularly
with overseas clients online - wherever they may be based. Wherever we travel
we always take ourselves with us. An escape from home to go and "live the
dream" can occasionally end up as a nightmare though if we bring unresolved
personal issues along in our suitcase. When layers of new challenges then land
on top it can sometimes result in overwhelm. I can help you clear that heavy
emotional baggage!</p>
<br>
<p>Equally, if you are home based my multi-disciplinary approach in assisting you
with problem solving, healing emotional wounds, goal setting and mentoring for
success, can help you to thrive!</p>
<br>
<p>Just use the links below to make contact and have an initial chat.</p>
<p style="line-height: 40px; padding-bottom: 0px">
I look forward to hearing from you – <span class="signature">Lynda</span>
</p>
<p style="text-align: center">
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/contact-details-bottom.php'); ?>
</p>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<!-- >>>>>>>>>>>>>>> FOOTER <<<<<<<<<<<<<<<<< -->
<?php include($_SERVER['DOCUMENT_ROOT'].'/_a_includes/footer.php'); ?>
</div>

<!-- >>> JQUERY <<< -->
<script src="/jquery/jquery.min.js"></script>
<script src="/cookienoticepro/cookienoticepro.script.js"></script>

<script>
	$(document).ready(function() {
		// Initialize cookie consent banner
		cookieNoticePro.init();
	});
	
	// IMPORTANT: If you are not showing cookie preferences selection menu,
	// then you can remove the below function
	const injectScripts = ()=>{
		// Example: Google Analytics
		if (cookieNoticePro.isPreferenceAccepted("analytics") === true) {
			console.log("Analytics Scripts Running....");
		}

		// Example: Google Adwords cookie, DoubleClick, Remarketing pixels, Social Media cookies
		if (cookieNoticePro.isPreferenceAccepted("marketing") === true) {
			console.log("Marketing Scripts Running....");
		}

		// Example: Remember password, language, etc
		if (cookieNoticePro.isPreferenceAccepted("preferences") === true) {
			console.log("Preferences Scripts Running....");
		}
	} 
</script>

<!-- >>> Bootstrap | Front End Framework <<< -->
<script src="/bootstrap/js/bootstrap.min.js"></script>

<!-- >>> CUSTOM JS <<< -->
<script src="/js/script.js"></script>
</body>
</html>