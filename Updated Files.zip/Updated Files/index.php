<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
	<title>Lynda Brettle | Expat Mentors</title>
	<meta name="description" content="Expat living on the Costa Blanca in Spain.  Life coaching on the Costa Blanca in Spain. Counselling and healing on the Costa Blanca in Spain." />
	<meta name="keywords" content="Expat living, life coaching, counselling and healing, Spain, Costa Blanca, Wellness, mentoring, Brains at the Border, Lynda Brettle" />
	<link rel="stylesheet" href="/style.css" />
</head>

<body>
	<div class="overlay">
		<!-- >>>>>>>>>>>>>>> NAVBAR <<<<<<<<<<<<<<<<< -->
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/header.php'); ?>

		<!-- >>>>>>>>>>>>>>>>> HERO BANNER <<<<<<<<<<<<<<<<<<< -->

		<div class="hero-banner-animated">
			<div class="section full-height">
				<div class="absolute-center">
					<div class="section">
						<div class="container">
							<div class="row">
								<div class="col-12">
									<h1 class="text-white">
										<span class="para-before">Welcome to</span>
										<br />
										<div class="heading-word-wrap">
											<span>E</span>
											<span>x</span>
											<span>p</span>
											<span>a</span>
											<span>t</span>
										</div>
										&nbsp;
										<div class="heading-word-wrap">
											<span>M</span>
											<span>e</span>
											<span>n</span>
											<span>t</span>
											<span>o</span>
											<span>r</span>
											<span>s</span>
										</div>
									</h1>
									<p class="text-white">
										Offering life coaching, personal counselling and emotional healing at home or away. Helping expatriates handle the psychological and stressful aspects of life abroad.
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="social-icons">
					<ul>
						<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/contact-details-top.php'); ?>
					</ul>
				</div>
			</div>
		</div>

		<div class="my-5 py-5"></div>

		<!-- >>>>>>>>>>>>>>>>> MAIN CONTENT <<<<<<<<<<<<<<<<<<< -->

		<div class="body-content">
			<div class="container-fluid">
				<div class="content-area">
					<div class="direction">
						<p>
							<a title="Expat living" href="https://www.expatmentors.com/">Expat Mentors</a> / Welcome
						</p>
					</div>
					<div class="covid-pandemic">
						<p>
							<b>Hello and Welcome!</b> My name is Lynda Brettle and I have a wealth of experience with over thirty-five years living and working all over the world, dealing with people from every walk of life and widely diverse cultural and linguistic backgrounds. Over the last decade I have branched out from my original career, and organisational management, into life coaching, mentoring, personal counselling and natural energy healing treatments.
						</p>
						<p>
							The international travel and expat lifestyle I enjoyed combined with my passion for mental health and wellbeing enables me to connect particularly with overseas clients online - in any location. Equally, if you are returning home after a spell abroad, or you have always been home based, my multi-disciplinary approach in assisting with problem solving, healing emotional wounds, goal setting and mentoring for success, can help you to thrive in your personal life and/or in the workplace.
						</p>
					</div>
					<div class="about-lynda">
						<div class="row">
							<div class="col-lg-3">
								<div class="profile">
									<a title="Brains at the Border book by Lynda Brettle - Life Coach" target="_blank" href="https://www.amazon.co.uk/dp/B08BRHDMNM">
										<img alt="Counselling and coaching on the Costa Blanca in Spain" src="_a_images/expat-living-book.png" />
									</a>
								</div>
							</div>
							<div class="col-lg-9 my-auto pr-2">
								<div class="text">
									<p>Wherever we travel, we always take ourselves with us. An escape from home to go and "live the dream" can sometimes end up as a nightmare though if we bring unresolved personal issues along with our suitcase. When layers of new challenges then land on top it can sometimes result in overwhelm. In 2020 my first book <b>"<a title="Brains At The Border by Lynda Brettle" target="_self" href="https://www.amazon.co.uk/dp/B08BRHDMNM/">Brains at the Border</a>"</b> was published and topped the Travel Writing Chart on Amazon. It offers a humorous insight into my own overseas experiences during postings with the UK Foreign Office in locations as diverse as paradise islands and wartorn conflict zones. With each new adventure I faced, with an eclectic bunch of fellow globe trotters, readers can experience how it really feels to live and work as an expatriate and how different people have dealt with both the rewards and frustrations of basic everyday issues.</p>
									<p>My nomadic lifestyle became increasing complex as I went from being a single girl to a married woman and a mother. In an attempt to regain some work – life balance, I left the Diplomatic Service and settled with my young family on Spain’s Costa Blanca. This is where the fun really began with the arrival of hordes of ill-prepared Brits saying they felt like they had left their <b>"<a title="Brains At The Border by Lynda Brettle" target="_self" href="https://www.amazon.co.uk/dp/B08BRHDMNM/">Brains at the Border</a>"</b>! The book is now available on all Amazon marketplaces in paperback and kindle editions. I hope that it is a useful resource to encourage others and helps to reassure people that they are not alone!</p>
									<p>Please just use the links below to make contact and have an initial chat about the level of support you feel you need.</p>
									<p>I look forward to hearing from you – <span class="signature">Lynda</span></p>
									<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/contact-details-bottom.php'); ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- >>>>>>>>>>>>>>> FOOTER <<<<<<<<<<<<<<<<< -->
		<?php include($_SERVER['DOCUMENT_ROOT'] . '/_a_includes/footer.php'); ?>
	</div>


	<!-- >>> JQUERY <<< -->
	<script src="/jquery/jquery.min.js"></script>
	<script src="/cookienoticepro/cookienoticepro.script.js"></script>

	<script>
		$(document).ready(function() {
			// Initialize cookie consent banner
			cookieNoticePro.init();
		});

		// IMPORTANT: If you are not showing cookie preferences selection menu,
		// then you can remove the below function
		const injectScripts = () => {
			// Example: Google Analytics
			if (cookieNoticePro.isPreferenceAccepted("analytics") === true) {
				console.log("Analytics Scripts Running....");
			}

			// Example: Google Adwords cookie, DoubleClick, Remarketing pixels, Social Media cookies
			if (cookieNoticePro.isPreferenceAccepted("marketing") === true) {
				console.log("Marketing Scripts Running....");
			}

			// Example: Remember password, language, etc
			if (cookieNoticePro.isPreferenceAccepted("preferences") === true) {
				console.log("Preferences Scripts Running....");
			}
		}
	</script>

	<!-- >>> Bootstrap | Front End Framework <<< -->
	<script src="/bootstrap/js/bootstrap.min.js"></script>

	<!-- >>> CUSTOM JS <<< -->
	<script src="/js/script.js"></script>
</body>

</html>